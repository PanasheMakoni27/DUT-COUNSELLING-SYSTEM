<?php session_start();  ?>
<?php include('header.php'); ?>

<style type="text/css">
	
.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
}

.splitdiv{
  height:100%;
  width:100%;
}

#leftdiv{
  float:left;
  background-color:#474e5d;
}

#leftdivcard{
  margin:0 auto;
  width:40%;
  height: 90%;
  background-color: #434956;
  margin-top: 35vh; 
  margin-left: 10vh;
  transform: translateY(-50%);
  border-radius:5px;
  color: white;
}

#button{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}
form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
</style>
<br>
<div class="about-section">
	<hr>
  	<h1>Help</h1>
  	<hr>
	<table>
			
	<form action="" method="post" class="text-center form-group">
		<tr>
			<td>
				<label>
					Email: 
					<input type="email" name="email"  value="" placeholder="email" required>
				</label><br><br>
					
				<label>
					<span> I need help with:</span><textarea name="feedback" id="" cols="100" rows="4" required></textarea>
				</label>
			</td>
		</tr>
		<tr>
			<td>
				<button name="submit" type="submit" id="button" class="ripple2">Send</button> 
			</td>
		</tr>
					


					<!-- User login validation -->
			<?php 
					
							include('config.php');
							if(isset($_POST['submit'])){
							

							$sql = "INSERT INTO feedback (email,feedback)	
							VALUES ('" . $_POST["email"] ."','" . $_POST["feedback"] ."')";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>alert('Thanks, please check your email for a response, we will help as soon as possible!');</script>";
							} else {
							    echo "<script>alert('There was an Error')<script>";
							}

							$conn->close();
						}
					
 			?>


				</form> <br>&nbsp;&nbsp;&nbsp;
				
		</table>
				<br>

				
                                <br><br>
				
			</div>
		

	
	
</div>
<?php include('footer.php'); ?>


</body>
</html>
