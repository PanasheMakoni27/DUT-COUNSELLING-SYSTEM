<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Meeting Session</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="stylec.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
	<style>
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  height: 580px;
  
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}

#leftbutton{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}
table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 1000px;

}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;


}

.item-align{
	align-items: flex-end;
}



.flip-card {
  background-color: transparent;
  width: 500px;
  height: 347px;
  perspective: 1000px;
  margin-left: 400px;
  margin-bottom: 400px;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}

.flip-card:hover .flip-card-inner {
  transform: rotateX(180deg);
}

.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
}

.flip-card-front {
  background-color: #d4d7de;
  color: black;
  padding-top: 30%;
}

.flip-card-back {
  background-color: #7d869b;
  transform: rotateX(180deg);
  padding-top: 0%;
  
}

.align{
	text-align: left;
}
button{
	
	background-color: #6f7990;
	border: none;
	color: white;
	width: 60%;
	height: 60px;
	font-size: 20px;
	animation: 10s;
	border-radius: 8px;
}
button:hover{
	 background-color: #d4d7de;
	 color: black;
}
.h2{
	padding-top: 10px;
}

</style>
</head>
                        
<body>
                        
<div class="about-section">

                        <hr>
			<h1>Join Online Counselling Session</h1>
			<hr>

<?php 

$now = date_create()->format('Y-m-d'); 

//$passwordMeeting = 

include('config.php');
include('api.php');

$sql = " SELECT * FROM booking WHERE email = '".$_SESSION["email"]."'  ";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count=1){
						

					while($row=mysqli_fetch_array($result)){
						

					$arr['topic']=$row['expertise'];



					if ($row['appoitmentType'] == 'Online' && $row['dates'] == $now ){

					$tyme = $row['tyme'];
				}



					echo"<br>";
				
}

//$arr['topic']='Testing for project'; 

$arr ['start_time'] = '';

$arr['start_date']=date('2022-09-13 00:20:38'); /**$arr['start_date']=date('Y-m h:i:s'); **/

$arr['duration']=60;

$arr['password']= "1234";

$arr['type']='2';

$result=createMeeting($arr);
	if (isset($result->id)) {

		//echo"JOIN URL: <a href='".$result->join_url."' target='_blank'>Click Here to Join<a><br>";
		//echo"PASSWORD: ".$result->password.  "<br>";
		//echo"START TIME".$result->start_time.  "<br>";

		//echo"Start Date: ";
		//echo"DURATION: ".$result->duration.  " Minutes<br>";

		echo'

		<div class="flip-card">
 			<div class="flip-card-inner">
    			<div class="flip-card-front">
    				<h2><b>Join Meeting<br></b></h2>
    			</div>
    		<div class="flip-card-back" >
    		<p align="left">
    		<h4 align="center">
    		Meeting Details <br><hr><br></h4><h5>
			Duration: '.$result->duration.'<br>
    		Password: '.$result->password. '<br><br>
    		</h5>
    		</p>

    		<button name="submit2" type="submit2">JOIN URL: <a href="'.$result->join_url.'" target="_blank">Click Here to Join<a><br></button>
    		</div>
  		</div>
		</div>';

	}
	else{

	echo '<pre>';
	print_r($result); 
	}
}

?>

</div>
</body>
 <?php include('footer.php'); ?>

	<script src="js/bootstrap.min.js"></script>
</html>

