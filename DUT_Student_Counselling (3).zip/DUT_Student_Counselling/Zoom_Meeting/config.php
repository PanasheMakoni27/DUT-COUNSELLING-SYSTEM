<?php
define('API_KEY','_JivL8grSJOwypsXalPpBw');
define('API_SECRET','g6yIUuWM232ACgUJ1MNbhcMeYWcsHxJeG3v6');
define('EMAIL_ID','damiennaicker07@gmail.com');


$servername = "localhost";
		$username = "root";
		$password = "Sabelo12345";
		$dbname = "codeologistwebapp";

		// Creating a connection 
			$conn = new mysqli($servername, $username, $password, $dbname);
				// Checking the status of the connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
							}
?>