<!DOCTYPE html>
<html>
<head>
    <title>HTML and CSS Slideshow</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
     .par {text-align: center;
		color: white;
		text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  }
  .y{
	  color: white;
	  background-color: green;
	  text-align: center;
	  font-size: 180%;
	  font-weight: bold;
	  min-height:42px!important;
  }

     
    #slideshow {
        overflow: hidden;
        height: 510px;
        width: 100%;
        margin: 0 auto;
    }
     

     
    .slide {
        float: left;
        height: 510px;
        width: 728px;
    }
     

     
    .slide-wrapper {
         
        /* Calculate the total width on the
      basis of number of slides */
        width: calc(728px * 4);
         
        /* Specify the animation with the
      duration and speed */
        animation: slide 30s ease infinite;
    }
     

     
    .slide:nth-child(1) {
        background-image: url("virtual-spring-removebg-preview.png");
		background-size: 100% 510px;
    }
     
    .slide:nth-child(2) {
        background-image: url("iStock-1182390029.jpg");
		background-size: 100% 510px;
    }
     
    .slide:nth-child(3) {
        background-image: url("4-Reasons-Why-Counseling-Is-So-Important-scaled.jpg");
		background-size: 100% 510px;
    }
     
    .slide:nth-child(4) {
       
		background-image: url("college-students-3990783_960_720.jpg");
		background-size: 100% 510px;
    }
     

     
    @keyframes slide {
         
        /* Calculate the margin-left for
      each of the slides */
        20% {
            margin-left: 0px;
        }
        40% {
            margin-left: calc(-728px * 1);
        }
        60% {
            margin-left: calc(-728px * 2);
        }
        80% {
            margin-left: calc(-728px * 3);
        }
    }
    </style>
</head>
 
<body>
     
    
    <div id="slideshow">
        <div class="slide-wrapper">
             
            
            <div class="slide">
                <h1 class="slide-number">
                    
                </h1>
            </div>
            <div class="slide">
                <h1 class="slide-number">
				<br></br><br></br><br>
                    <div class =" par" >We are here to provide student support and career development<div>
                </h1>
            </div>
            <div class="slide">
                <h1 class="slide-number">
                 <br></br><br></br>
                    <div class =" par" ><a href="student_login.php">Book Your Appoitment Now!!</a><br>And<br> Get A Professional Help<div>
                </h1>
            </div>
            <div class="slide">
                <h1 class="slide-number">
                    <br></br><br></br>
                    <div class =" par" >DUT Student Counselling <br>We are here for You<div>
                </h1>
            </div>
        </div>
    </div>
	<br>


</body>
</html>
