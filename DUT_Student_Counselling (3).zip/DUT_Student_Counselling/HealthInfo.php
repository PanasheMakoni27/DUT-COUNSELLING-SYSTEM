<?php include('header.php'); ?>

<style type="text/css">

.info {

  border: 0.5px solid grey;
  border-radius: 8px;
  padding: 5px;
  max-width: 400px;
  max-height:570px;
  margin: auto;
  text-align: center;
  border: none;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  background-color: none;
  
}

.title {
  color: grey;
  font-size: 18px;
}
.title1 {
  color: darkgray;
  font-size: 13.5px;
}


/* Set height of body and the document to 100% to enable "full page tabs" */
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial;
}

/* Style tab links */
.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

.tablink:hover {
  background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
  color: black;
  display: none;
  padding: 100px 20px;
  height: 100%;

}

#Home {background-color: #ff9933;}
#News {background-color: #33cc33;}
#Contact {background-color: #6699ff;}
#About {background-color: #ffd633;}

table{
  background-color: #ff9933;
  opacity: 1;
}
tr{
  background-color: #ff9933;
  opacity: 1;
}
td{
  background-color: #ff9933;
  opacity: 1;
}

.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
}

.accordion {
  background-color: rgba(0, 0, 0, 0.0);
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #4d88ff;
}

.accordion:after {
  content: '\002B';
  color: black;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active:after {
  content: "\2212";
}

.panel {
  padding: 0 18px;
  background-color: rgba(0, 0, 0, 0.0);
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}
</style>
</head>
<body>
  
<div class="counsellors">
<div class="form-group mc">
<br>
<div class="about-section">
  <hr><h1>Health and Well Being</h1><hr><br>



<button class="tablink" onclick="openPage('Home', this, '#ff9933')"id="defaultOpen">What is Mental Health?</button>
<button class="tablink" onclick="openPage('News', this, '#33cc33')">Need help?</button>
<button class="tablink" onclick="openPage('Contact', this, '#6699ff')">Common Mental Health Challenges</button>
<button class="tablink" onclick="openPage('About', this, '#ffd633')">Get Help</button>


<div id="Home" class="tabcontent">
 <h3>What is mental health?</h3>
 	<p>
			Mental health plays an important role when it comes to how well students perform academically with many students feeling overwhelmed by not only their studies, but coping with their everyday lives as well. mental health problems like depression and anxiety and thoughts of suicide, it’s important to promote student mental health as part of universities mental health prevention programmes.

			Covid-19 and the lockdown has affected many South Africans, and it has had a serious impact on people living with a mental health issue often making their symptoms more heightened. SADAG (SA Depression and Anxiety Group) has been receiving calls from people with no history of anxiety or depression who are feeling overwhelmed, anxious and stressed

			Universities that are currently preparing for the safe return of students to campuses against the backdrop of the COVID-19 pandemic cannot neglect the psychosocial support that will be needed by students and staff
	</p>
</div>


<div id="News" class="tabcontent">
    <h3>Join our <a href="https://chat.whatsapp.com/CPZtPGcF1ze28hOdbv5FOZ">WhatsApp group</a> to ask questions</h3>
  <p>

	</p>
</div>

<div id="Contact" class="tabcontent">
	<h3>Common mental health issues</h3>

		  <button class="accordion">Depression</button>
		  <div class="panel">
			
  		<p>Depression is a mood disorder that involves persistent feelings of sadness, 
			hopelessness, and loss of interest in previously enjoyable activities. 
			People experiencing depressive episodes may also experience mood swings, 
			sleep disturbances, appetite changes, and headaches and body pains that 
			have no apparent physical cause. 
		  </p><hr>
			</div>

			<button class="accordion">Anxiety</button>
			<div class="panel">
  		
  		<p>
  			Everyone experiences anxiety from time to time. However, mounting, ongoing feelings
				of worry, tension, and panic can interfere with daily life. When your daily life 
				is disrupted, anxiety crosses the line to become a medical condition.
				Mental health professionals define suicidal ideations as a prevalent pattern 
				of thinking about or planning one's own death by one's own hand. Generally, 
				experts consider overwhelming or highly detailed suicidal thoughts a mental health crisis.
		  </p><hr>
			</div>

			<button class="accordion">Eating Disorders</button>
			<div class="panel">
  		
  		If you need assistance helping a friend through an eating disorder, or if you need to
			understand more about them before you come to terms with the fact that you may have one,
			the following list of resources are a good place to start.
		  </p><hr>
			</div>

			<button class="accordion">Suicide</button>
			<div class="panel">
  		
  		<p>
  		Mental health professionals define suicidal ideations as a prevalent pattern 
			of thinking about or planning one's own death by one's own hand. Generally, 
			experts consider overwhelming or highly detailed suicidal thoughts a mental health crisis.

			Remember: If you feel that someone's life is in danger, immediately call 911.
			It's important that anyone who may be suicidal receives the help they need as
			soon as possible. A majority of college students who take their lives have a 
			diagnosable and treatable mental illness.
		  </p>

		  <div class="w3-content w3-section" style="max-width:447px; background-color:#ffe6e6">      
  			<h2 class="visually-hidden">Suicide Prevention Lifeline</h2>
  			<div class="block-content">
          <div  class="clearfix text-formatted field field--name-body field--type-text-with-summary field--label-hidden field__item"><p><a href="https://suicidepreventionlifeline.org/"><img alt="National Suicide Prevention Lifeline 1-800-273-8255" data-entity-type="file" data-entity-uuid="184f255d-ec20-4ef4-a249-f87021810610" src="//www.mentalhealth.gov/sites/default/files/inline-images/suicidepreventionbanner_0.png" width="447" height="179" loading="lazy" /></a></p></div>
        </div>
			</div>
			<hr>
			</div>

			<button class="accordion">Addiction</button>
			<div class="panel">
  		
  		<p>
  		College students frequently use alcohol and recreational drugs, which can become
			problematic. Addiction describes a tangible pattern of physical and/or psychological
			dependence on one or more substances, including strong cravings and indulgence in 
			substance abuse despite known risks and harms.
		  </p><hr>
			</div>
		</div>

<div id="About" class="tabcontent">

  <h3>Get help</h3>
  <h4> <a href="student_regi.php">Sign Up today</a></h4>
</div>

<br><br>
</div>



  <?php include('footer.php'); ?>
</div>
</div>
	

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="js/ytembed.min.js"></script>
	<script src="js/jquery-1.9.0.min.js"></script>
	<script src="js/ytembed.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="js/bootstrap.min.js"></script>

	<script>
function openPage(pageName, elmnt, color) {
  // Hide all elements with class="tabcontent" by default */
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(pageName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
</script>

</body>
</html>