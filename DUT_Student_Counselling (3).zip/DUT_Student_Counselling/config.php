<?php	$servername = "localhost";
		$username = "root";
		$password = "Sabelo12345";
		//$password = "";
		$dbname = "codeologistwebapp";

		// Creating a connection 
			$conn = new mysqli($servername, $username, $password, $dbname);
				// Checking the status of the connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
							}
?>	