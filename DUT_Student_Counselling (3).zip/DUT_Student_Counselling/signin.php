<?php session_start();  ?>
<?php include('header.php'); ?>
<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
}
	.login-section {
  padding: 50px;
  text-align: left;
  background-color: #479e5d;
  color: white;
}



/* This allow me to have the full width of the page without the initial padding/margin*/
body, html {
  margin:0;
  padding:0;
  height: 100%;
  width:100%;
  font-family:Acme;
  min-width:700px;
}

.splitdiv{
  height:100%;
  width:50%;
}

/* This part contains all of the left side of the screen */
/* ----------------------------------------- */
#leftdiv{
  float:left;
  background-color:#ddd;
}

#leftdivcard{
  margin:0 auto;
  width:68%;
  height: 48%;
  background-color:white;
  margin-top: 50vh; 
  transform: translateY(-50%);

  border-radius:5px
}

#leftbutton{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}

/* ----------------------------------------- */

/* This part contains all of the left side of the screen */
/* ----------------------------------------- */
#rightdiv{
  float:right;
  background-color:#333;
}

#rightdivcard{
  margin:0 auto;
  width:50%;
  margin-top: 50vh;
  transform: translateY(-50%);
  

}

#rightbutton{
    background-color:#FFFFFF;
    border-radius:5px;
    color:#00cc00;
}
/* ----------------------------------------- */

/* Basic styling */
/* ----------------------------------------- */


input{
  font-family:Acme;
  font-size:16px;
}

input{
  width:85%;
  height:40px;
  padding:10px;
  margin-left:2%;
  margin-right:2%;
  margin-top:10px;
  margin-bottom:10px;
  display:inline-block;
  background-color:#FAFAFA;
  border:none;
  font-family: 'Quicksand', sans-serif;
}

input:focus {
    outline: none !important;
    border:1px solid #4ECDC4;
    box-shadow: 0 0 5px #719ECE;
}

a{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
}



.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}

</style>

<div class="about-section">
  <br>
  <hr><h1>Student Login</h1><hr>

</div>


    <div style="height:100%;width:100%;display:inline-block">
      
    <div class="splitdiv" id="leftdiv">
      <div id="leftdivcard">
      	<form action="" method="post" class="text-center form-group">
        <h1 style="padding-top:20px;text-align:center">Sign In</h1>
          
          <input type="email" name="email"  placeholder="email" required>
          <input type="password" name="password"  placeholder="password" required>
          <div style="text-align:center">
           
            <button name ="submit" type="submit" id="leftbutton" class="ripple2">Sign In</button>

          </div>
      </div>

      					<!-- login validation -->
			<?php 
					$_SESSION['student']="";
							
							include('config.php');
							if(isset($_POST["submit"])){

                                                        // FIRST CHANGE
                                                        $password = $_POST['password'];

                                                        $hash = sha1($password);
                
                                                        //$q = $db->query("SELECT * FROM admin WHERE username = '$username' AND password = '$hash' LIMIT 1 ");
                                                        //END
							$sql= "SELECT * FROM student WHERE email= '" . $_POST["email"]."' AND password= '$hash' LIMIT 1 ";

							$result = $conn->query($sql);

									if ($result->num_rows > 0) {
											$_SESSION["email"]= $_POST["email"];
											$_SESSION['student']= "yes";
										    echo "<script>location.replace('student/studentdashboard.php');</script>";
												// echo "u are supposed to redirect to ur profile";
										} else {
										    echo "<script>alert('Invalid username or password');</script>";
										}
						$conn->close();		
					}
					
 			?>


 		</form>
    </div>
      
    <div class="splitdiv" id="rightdiv">
      <div id="rightdivcard">
        <h1 style="padding-top:20px;text-align:center;color:white">New here ?</h1>
        <p style="color:white;text-align:center">Sign Up and book your counselling session</p>
        <div style="text-align:center">
           <a href="student_regi.php" id="rightbutton" >Sign Up</a>
            
        </div>
      </div>
    </div>


<div class="about-section">


  <h1 style="padding-top: 630px;text-align:center;color:white"><hr>Counsellor Login</h1>
 
        <div style="text-align:center">
           <a href="counsellorsLogin.php" id="rightbutton" >Sign In</a>
         </div><hr>
   <h1 style="text-align:center;color:white">Administrator Login</h1>
 
        <div style="text-align:center">
           <a href="admin/index.php" id="rightbutton" >Sign In</a>
         </div><hr>
</div>

 <?php include('footer.php');?>






<script src="js/bootstrap.min.js"></script>





	
</body>
</html>







