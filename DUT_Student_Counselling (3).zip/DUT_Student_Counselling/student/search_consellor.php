<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('uptomenu.php'); ?>

<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
 font-size: 20px;
}

.container {
  height: 0px;
  margin: 50px auto;
  color: #474e5d;
}

ul {
  list-style: none;
  display: flex;
  width: 100%;
  padding: 0px;
  background-color: #474e5d;

}

ul li {
  position: relative;
  color: white;
  width: 33.333333%;
  text-align: center;
  background-color: #474e5d;

}
 
ul li:before {

  display: flex;
  align-items: center;
  justify-content: center;
  
  content: attr(data-step);
   
  width: 40px;
  height: 40px;
  border-radius: 50%;
  
  background: white; 
  color: black;

  position: absolute;
  top: -50px;
  left: calc(50% - 20px);
  z-index: 99;
}

ul li:after {

  content: '';
  width: 100%;
  height: 5px;
  background: var(--light-grey);
  
  position: absolute;
  top: -35px;
  left: -50%;
}

ul li:first-child:after {
   width: 0;
}

ul li.active:before {
  background: var(--green);
  color: #fff;
}

ul li.active:after {
  background: var(--green);
}

ul li.active {
  color: var(--green);
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 100px;
  text-align: center;
  cursor: pointer;
  padding-left: 18px;

}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;

}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
h3{
	color: white;
}

</style>




		<div class="about-section">
			<hr>
			<h1>Search for Type of Counselling</h1>
			<hr>
			<br>
      <table>
        <tr>
          <td>
	          <div class="container">
              <ul class="progressbar">
                <li data-step="1"class="active" >Select Type of Counselling</li>
                <li data-step="2">Select Counsellor</li>
                <li data-step="3">Booking</li>
              </ul>
            </div>
          </td>
        </tr>
      </table>


      <table>
        <tr>
          <td>
            <form action="search_result.php" method="post" class="form-group" >
            <hr>
    	         <table>
		              <tr>
			             <td>
			               <h3>Select a Type of Counselling:</h3>
			             </td>
			             <td>
				              <select name="expertise" type="text" style="width: 260px;" required>
												<option value="">Select a type of session</option>
												<option>Individual Counselling </option>
												<option>Career Counselling</option>
												<option>Academic Counselling </option>
												<option>Religious Counselling</option>
											</select>
			             </td>
		              </tr>
                </table>
                <table>
		               <tr>
			               <td>
			                 <button name="submit" type="submit" id="button" class="ripple2">Search </button><br><br>
			               </td>	
		                </tr>
                </table>			
              </form>
            </td>
          </tr>
        </table>
      </div>






	<script src="js/bootstrap.min.js"></script>
	



</body>
<?php include('footer.php'); ?>

	<script src="js/bootstrap.min.js"></script>
</html>