<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('uptomenu.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
.details-section
{
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;

}
form{
	text-align: left;
	width: 500px;
	background-color: #474e5d;
}
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;

}

.container {
  margin: 50px auto;
  background-color: #474e5d;
}

ul {
  list-style: none;
  display: flex;
  width: 100%;
  padding: 0;
}

ul li {
  position: relative;
  color: white;
  width: 33.333333%;
  text-align: center;
  background-color: #474e5d;
  font-size: 20px;
}
 
ul li:before {

  display: flex;
  align-items: center;
  justify-content: center;
  
  content: attr(data-step);
   
  width: 40px;
  height: 40px;
  border-radius: 50%;
  
  background: white; 
  color: black;

  position: absolute;
  top: -50px;
  left: calc(50% - 20px);
  z-index: 99;
}

ul li:after {

  content: '';
  width: 100%;
  height: 5px;
  background: var(--light-grey);
  
  position: absolute;
  top: -35px;
  left: -50%;
}

ul li:first-child:after {
   width: 0;
}

ul li.active:before {
  background: var(--green);
  color: #fff;
}

ul li.active:after {
  background: var(--green);
}

ul li.active {
  color: var(--green);
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}

form{
	padding: 0px;
	width: 100%;
	height: 100%;
	
}
input{
	color: black;
}
option{
	color: black;
}
select{
	color: black;
}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 36px;

}


</style>

<div class="search" style="background-color:;">
		<div class="about-section">
			<hr>
			<h1>Booking</h1>
			<hr>
			<br>
	<div class="container">
  <ul class="progressbar">
    <li data-step="1"class="active" >Select Type of Counselling</li>
    <li data-step="2"class="active">Select Counsellor</li>
    <li data-step="3" class="active">Booking</li>
  </ul>
</div>

<?php 
	$cou_id = isset($_GET['cou_id'])?$_GET['cou_id']:"";
	
 ?>
				<!-- Here we are fetching counsellors info -->
					<?php 

							include('../config.php');
					

							$sql="SELECT * FROM counsellors WHERE cou_id = $cou_id ";

							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
							    // output data of each row
							    while($row  = $result->fetch_assoc()) {
							        $cou_id   = $row["cou_id"];
									// differintiate doc details
							        $doc_name 	= $row["name"];
							        $demail 	= $row["email"];
							        $expertise 	= $row["expertise"];
							        $doc_contact 	= $row["contact"];
											$userid = $row["userid"];
							    }
							}
							
							$conn->close();

					?>
					<!-- Here we are fetching Student information -->
				<?php 
							include('../config.php');
							$sql="SELECT * FROM student where email='" . $_SESSION["email"] . "'";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							$name=$data[1];
							$age=$data[2];
							$contact=$data[3];
							$address=$data[4];
							$bgender=$data[5];
							$email=$data[6];

							mysqli_close($conn);
				?>	
					

	<!--Booking form-->

	
	
		<table>
			<tr>
				<td>
				<form action="" method="post" class="text-center form-group" enctype="multipath/form-data">
					<div class="details-section">
						<hr>
							<h3>Counsellor Details</h3>
						<hr>
						<br>

					<label>
						Counsellor Name: <input type="text" name="dname" value="<?php echo $doc_name; ?>" readonly="readonly" >
					</label><br><br>

					<label>
						Counsellor Email: <input type="text" name="demail" value="<?php echo $demail; ?>" readonly="readonly" >
					</label><br><br>

 					<label>
						Contact Number: <input type="text" name="dcontact" value="<?php echo $doc_contact; ?>" readonly="readonly" >
					</label>
 					
					<label>
						 <input type="hidden" name="pname" value="<?php echo $name; ?>" placeholder="Full name" readonly="readonly" required>
					</label>

 					<label>
						 <input type="hidden" name="pcontact" value="<?php echo $contact; ?>" placeholder="contact no" required="required" pattern="[0-9]{10,11}" title="please enter only numbers between 10 to 11 for mobile no."/>
					</label>
					<label>
						 <input type="hidden" name="email" value="<?php echo $email; ?>" placeholder="email" required>
					</label>
 					
					<label>
						 <input type="hidden" name="address" value="<?php echo $address; ?>" placeholder="address" readonly="readonly" required>
					</label><br><br><br>
						<hr>
							<h3>Session Details</h3>
						<hr>
						<br>
					<label>
						Counselling Type: <input type="text" name="expertise" value="<?php echo $expertise; ?>" readonly="readonly" >
					</label><br><br>
					<label>
						Date : <input id="date_picker" type="date" name="date" required>
						    <script language="javascript">
        					var today = new Date();
        					var dd = String(today.getDate()).padStart(2, '0');
        					var mm = String(today.getMonth() + 1).padStart(2, '0');
        					var yyyy = today.getFullYear();

        					today = yyyy + '-' + mm + '-' + dd;
        					$('#date_picker').attr('min',today);
        					
    						</script>

					</label>
					<br><br>
					<label>
						 Time: <select name="tyme" required>
										<option value="">-select-</option>
										<option value="08.00am">8:00am - 9:00am</option>
										<option value="09.00am">9:00am - 10:00am</option>
										<option value="10.00am">10:00am - 11:00am</option>
										<option value="12.00pm">11:00am - 12:00pm</option>
									</select>
					</label><br><br>
					<label>
						 Type of Session: <select name="appoitmentType" required>
										<option value="">-select-</option>
										<option value="Online">Online</option>
										<option value="Contact">Contact</option>
									</select>
					</label><br><br>
					<label>
						  <input type="hidden" name="userid" value="<?php echo $userid; ?>">
					</label><br><br>
					
					<button name="submit" type="submit" id="button" class="ripple2">Confirm</button> 
					<button id="button" class="ripple3"><a href="myDetails.php">Cancel</a></button><br>


				</form> 
			</td>
		</tr>
	</table><br><br>

			</div>
	
	
		</div>
				
			<!-- confirming appointment booking -->
					<?php

						include('../config.php');
						if(isset($_POST['submit'])){
							

						$sql = " INSERT INTO booking (dname,demail,userid,dcontact,expertise, pname,pcontact,email,address,dates,tyme,appoitmentType)
							VALUES ('" . $_POST["dname"] . "','" . $_POST["demail"] . "','" . $_POST["userid"] . "','" . $_POST["dcontact"] . "','" . $_POST["expertise"] . "','" . $_POST["pname"] . "','". $_POST["pcontact"] . "','". $_POST["email"] . "','". $_POST["address"] . "','". $_POST["date"] . "','". $_POST["tyme"] . "','". $_POST["appoitmentType"] . "' )";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>alert('Your booking has been accepted!');</script>";
								echo "<script>location.replace('view_booking.php');</script>";
							} else {
							    echo "<script>alert('There was an Error')<script>";
							}

							$conn->close();
						}
					?> 

	
	</div>
 <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>




 


	
</body>
</html>
