<?php include('uptomenu.php'); ?>

<!-- Here we are retrieving data -->
				<?php 
							include('../config.php');
							session_start();
							$sql="SELECT * FROM student where email='" . $_SESSION["email"] . "'";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							$name=$data[1];
							$age=$data[2];
							$contact=$data[3];
							$address=$data[4];
							$bgender=$data[5];
							$email=$data[6];

							mysqli_close($conn);
				?>
<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

form{
	text-align: left;
	width: 500px;
	background-color: #474e5d;
}
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
}

.container {
  margin: 50px auto;
}

ul {
  list-style: none;
  display: flex;
  width: 100%;
  padding: 0;
}

ul li {
  position: relative;
  color: white;
  width: 25%;
  text-align: center;
  background-color: #333;
}
 
ul li:before {

  display: flex;
  align-items: center;
  justify-content: center;
  
  content: attr(data-step);
   
  width: 40px;
  height: 40px;
  border-radius: 50%;
  
  background: white; 
  color: black;

  position: absolute;
  top: -50px;
  left: calc(50% - 20px);
  z-index: 99;
}

ul li:after {

  content: '';
  width: 100%;
  height: 5px;
  background: var(--light-grey);
  
  position: absolute;
  top: -35px;
  left: -50%;
}

ul li:first-child:after {
   width: 0;
}

ul li.active:before {
  background: var(--green);
  color: #fff;
}

ul li.active:after {
  background: var(--green);
}

ul li.active {
  color: var(--green);
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}

form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
input{
	color: #333;
}
</style>

		<div class="about-section">
			<hr>
			<h1>My Details</h1>
			<hr>
		
		<table>
			<tr>
				<td>
			
				<form action="" method="post" class="text-center form-group">
					
					<label>
						Your Name: <input type="text" name="name" value="<?php echo $name; ?>" placeholder="Full name" readonly="readonly">
					</label><br><br>

					<label>
						Age: <input type="number" name="age"  value="<?php echo $age; ?>" placeholder="age" required="required" pattern="[0-9]{2,2}" title="please enter only  numbers between 2 to 2 for age"/>
					</label><br><br>
					<label>
						Mobile: <input type="text" name="contact" value="<?php echo $contact; ?>" placeholder="contact no" required="required" pattern="[0-9]{10,11}" title="please enter only 10 digits for mobile number"/>
					</label><br><br>
 					
 					<label>
						Address: <input type="text" name="address" value="<?php echo $address; ?>" placeholder="address" title="please enter All phyical address details with code" required>
					</label><br><br>
					<label>
						Gender: <input type="text" name="gender" value="<?php echo $bgender; ?>" placeholder="email" disabled>
					</label><br><br>

					<label>
						Email: <input type="email" name="email" value="<?php echo $email; ?>" placeholder="email" required>
					</label><br><br>
					
					
					
					<button name="submit" type="submit" style="margin-right:43px;width:160px;border-radius: 3px;">Update Profile</button> <br>


			</form>
		</td>
	</tr>
</table>
			 <br>
				
				<br>

				
		
				
			
		
	
	
	
</div>





				<?php
							include('config.php');
							if(isset($_POST['submit'])){
							

							$sql="UPDATE student SET name='" .$_POST["name"]. "' ,age='" .$_POST["age"]."' , contact='" .$_POST["contact"]. "',address='" .$_POST["address"]. "', email='".$_POST["email"]."' WHERE email='" .$_SESSION["email"]. "'";
		
							if (mysqli_query($conn, $sql)) {
						    echo "<script>alert(' Record updated successfully');</script>";
							echo "<script>location.replace('myDetails.php');</script>";
							} else {
							    echo "<script>alert('There was a Error Updating profile');</script>";
							}

						mysqli_close($conn);
													}
					?> 



  <?php include('footer.php'); ?>


</body>
</html>