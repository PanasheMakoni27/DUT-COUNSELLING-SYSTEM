<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('uptomenu.php'); ?>

<style type="text/css">
	
		.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  width: 100%;
}

table{
  align-items:center;
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;

}

th{
  text-align: center;
  max-width: 200px;
  font-size: 18px;
}
input{
	height: 10px;
	padding-left: 1px;
}

button{
	border: none;
	border-radius: 1px;
	height: 25px;
	width: 25px;
	padding-left: 1px;
	
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.2s;
  width: 100%;
  color: black;
  background-color: white;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,1.0);
}

.container {
  padding: 2px 16px;
  padding-top: 5px;
  padding-left: 10px;
  padding-bottom: 10px;
}


:root {
            /* color */
            --background-color-1            :   #474e5d;
            --background-color-2            :   #474e5d;
            --pufferfish-outline-color      :   #cce6ff;
            --pufferfish-body-color-1       :   #cce6ff;
            --pufferfish-body-color-2       :   #99ccff;
            --pufferfish-body-color-3       :   #cce6ff;
            

            /* size */
            --pufferfish-width              :   250px;
            --pufferfish-height             :   250px;
           
            

            /* misc */
            --thick-border                  :   5px solid var(--pufferfish-outline-color);
            --thin-border                   :   3px solid var(--pufferfish-outline-color);
            --pufferfish-bloat-duration     :   10s;
        }
        @keyframes bgColorAnimate {
            0%, 5%, 95%, 100% { background: var(--background-color-1) }
            40%, 60% { background: var(--background-color-2) }
        }
        @keyframes bloatAnim {
            0%, 5%, 95%, 100% { transform: var(--transform-1) }
            50%, 50% { transform: var(--transform-2) }
        }

            body {
              color: white;
              animation: bgColorAnimate var(--pufferfish-bloat-duration) linear infinite;
        }

        main {
            display: flex;
            flex-direction: column;
            padding-left: 300px;
        }
        .pufferfish {
            height: var(--pufferfish-height);
            width: var(--pufferfish-width);
        }
        .pufferfish > * {
            position: absolute;
        }
        .pufferfish__body {
            background: linear-gradient(to bottom, var(--pufferfish-body-color-2) 0%,
                var(--pufferfish-body-color-2) 50%,
                var(--pufferfish-body-color-1) 0%);
            height: var(--pufferfish-height);
            width: var(--pufferfish-width);
            border-radius: 50%;
            border: var(--thick-border);
            --transform-1: rotateX(70deg);
            --transform-2: rotateX(0deg);
        }
        .pufferfish__body {
            transform: var(--transform-1);
            --custom-animation: bloatAnim;
            animation-name: var(--custom-animation);
            animation-duration: var(--pufferfish-bloat-duration);
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        } 
        @keyframes breatheTextAnim {
            50%, 100% { content: "BREATHE OUT" }
            0%, 49% { content: "BREATHE IN" }
            100%, 0%, 12%, 50%, 62% { opacity: 0 }
            15%, 40%, 65%, 90% { opacity: 1 }
        }
        .breathe-text {
            text-align: center;
            margin: 0 0 20px 0;
            width: 250px;
            font-size: 20px;
            font-family: Quicksand;
        }
        .breathe-text::before {
            content: "BREATHE IN";
            font-weight: 900;
            font-size: 20px;
            letter-spacing: 8px;
            font-family: Quicksand;

            animation: breatheTextAnim var(--pufferfish-bloat-duration) linear infinite;
        }


</style>


<div class="about-section">
<br>
<hr><h1>My Dashboard</h1><hr>



<div class="about-section">

<hr><h3>Upcoming Appointments</h3><hr>
<br>
<?php
	include('../config.php');
		
		$sql = "SELECT * FROM booking WHERE email = '".$_SESSION["email"]."' ORDER BY dates ASC LIMIT 1  ";
		mysqli_query($conn, $sql);

		$result = $conn->query($sql);

		$count = mysqli_num_rows($result);

        if($count>=1){
		
		while($row  = $result->fetch_assoc()) {						    

            echo"<div class='card'>";
            echo"<div class='container'>";
            echo"<h3><b>Upcoming Appointments</b></h3>";
            echo"<p><h4>You have an upcoming <b>".$row['appoitmentType']."</b> appoinment with <b>".$row['dname']."</b> on the <b>".$row['dates']."</b> at <b>".$row['tyme']."</b></h4></p>";
            echo"</div>";
            echo"</div>";
          }
							}
else{

echo'<div class="card">';
echo' <div class="container">';
echo'  <h4><b>Upcoming Appointments</b></h4> ';
echo'   <p>You have no upcoming appointments</p> ';
echo'  </div>';
echo'</div>';

}
							
			$conn->close();


        
?>

<br><br>
<hr><h3>Take sometime to breathe</h3><hr>
    <main>
        <label class="breathe-text"></label>
        <div class="pufferfish">
            <div class="pufferfish__body"></div>
        </div>
    </main>
</div>

</div>
</div>
</div>


<br>

<?php include('footer.php'); ?>


<script src="js/bootstrap.min.js"></script>
</body>
</html>
