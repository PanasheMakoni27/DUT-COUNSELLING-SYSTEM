<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>STUDENT COUNSELING CENTRE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
  <link rel="stylesheet" href="../student/css/bootstrap.min.css">
  <link rel="stylesheet" href="../style.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.7.2.min.js"></script>
  <style>
    .error {color: #FF0000;}

    /* Create a top navigation bar with a black background color  */
    .topnav {
    background-color: #333;
    overflow: hidden;
    border: 2px solid #00cc00;
    top: 0;
    font-family: Quicksand;
    width: 100%;
    }

    /* Style the links inside the navigation bar */
  .topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 18px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create a right-aligned (split) link inside the navigation bar */
.topnav a.split {
  float: right;
  background-color: #00cc00;
  color: white;
}


/*SIDE NAVIGATION */

body {
  font-family: Quicksand;
  transition: background-color .5s;
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #333;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #00cc00;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  margin-right: 0px;
  margin-left: 0px;
  width: 250px;
  padding-left: 80px;
  padding-top: 15px;
  font-size: 18px;
  height: 58px;
  border: 2px solid #00cc00;
 /* border-right: #00cc00;*/
  background-color: #333;
  text-align: left;


}

#main {
  transition: margin-left .1s;
  padding: 0;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.button1{
  background-color: rgba(0, 0, 0, 0.0);
  color: white;
  padding: 0;
  padding-left: 0;
  padding-right: 0;
  width: 16px;
}
.topnav button:hover {
  background-color: #ddd;
  color: black;
}

.align{
  padding-left: 28px;
}
</style>
</head>
<body>


  <div class="topnav">
  <a><div id="main">
  <button class="button1"  onclick="openNav()"> &#9776; </button>
</div></a>
  <!--<a href="myDetails.php"><img src="dutLogo.png" alt="" width = "19px" height = "19px"></a>-->
  <a href="studentdashboard.php"><i class="fa fa-fw fa-home"></i>Home</a>
  <a href="search_consellor.php"><i class="fas fa-calendar"></i> Appointment Booking</a>
  <a href="view_booking.php"><i class="fas fa-calendar-check"></i> My Appointments</a>
  <!--<a href="changepwd.php">Change Password</a>-->  
  <a href="../signin.php" class="split"><i class="fa fa-fw fa-user"></i>Logout</a>
</div>

<div id="mySidenav" class="sidenav">
  
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class='fa fa-times'></i> Close</a>
  <a href="myDetails.php"><i class="far fa-address-card"></i>   My Details</a>
  <a href="changepwd.php"><i class="fa fa-key"></i>  Change Password</a>
  <a href="pastAppointments.php"><i class="fa fa-clock"></i>  Past Appointments</a>
  <a href="feedback.php"><i class="far fa-comments"></i>  Feedback and <div class="align">Queries</div></a>

</div>




<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
   
</body>


