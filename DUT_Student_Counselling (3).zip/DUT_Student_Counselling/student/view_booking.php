<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php
					if(isset($_POST["submit"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:../Zoom_Meeting/index.php?".$queryString);
        				die();

        			}
?>
<?php include('uptomenu.php'); ?>
<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;

}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 25px;

}

#leftbutton{
    background-color:#00cc00;
    color:#FAFAFA;
}
table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
th{
	text-align: center;
	max-width: 200px;
	font-size: 18px;
}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;
}
a{
	color: white;
}
.item-align{
	align-items: flex-end;
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  
  text-align: center;
  cursor: pointer;
}



</style>

<!--<div class="search" style="background-color:;">-->
		<div class="about-section">
			<hr>
			<h1>My Appointments</h1>
			<hr>
			<br>

	

			<!--\\<div class="all_user" style="margin-top:0px; margin-left: 40px;">-->
				<?php 
				$now = date_create()->format('Y-m-d');
					include('../config.php');

					$sql = " SELECT * FROM booking WHERE email = '".$_SESSION["email"]."' ORDER BY dates ASC, tyme ASC ";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count>=1){
						echo "<table border='1' align='center' cellpadding='40'>
							<tr>
								<th>My Session Type</th>
								<th>My Counsellor</th>
								<th>Counsellor Email</th>
								<th>Appoinment Date</th>
								<th>Time</th>
								<th>Cancel Booking</th>
								<th>Session Type</th>
							</tr>";
							while($row=mysqli_fetch_array($result)){
									echo "<tr>";
									echo "<td>".$row['expertise']."<hr></td>";
									echo "<td>".$row['dname']."<hr></td>";
									echo "<td>".$row['demail']."<hr></td>";
									echo "<td>".$row['dates']."<hr></td>";
									echo "<td>".$row['tyme']."<hr></td>";
								
									echo "<td><button name = 'submit1' class='ripple3' id='button'><a href='reasonforcancel.php?id=".$row['booking_id']."'>Cancel</a></button><hr></td>";

									echo "<td>";
									if ($row['appoitmentType'] == 'Online' && $row['dates'] == $now) {
							
						
									echo'<form action="" method="post" class="text-center">
									<button name="submit" type="submit" class="ripple2" id="button">Join Session</button><hr>';
							}
							else if ($row['appoitmentType'] == 'Online') {
							
						
									echo'<form action="" method="post" class="text-center">
									<button name="submit" type="submit" class="ripple2" id="button">Join Session</button><hr>';
							}

						else {
							echo'Contact Meeting<hr>';
						}
								echo"</form>";

								echo"</td>";

						
								echo "</tr>";
						}
						echo "</table>";
					}
					else{
						print "<h3><p align='center'>Sorry it seems like you have not scheduled any bookings.<br><br>
						<button class='ripple2' id='button'><a href='search_consellor.php' h><h4>Book Now</h4></a></button></p></h3>";
					}

					?>


			<br><br><br><br><br><br>		
			</div>


	



	</div>


	
 <?php include('footer.php'); ?>

	<script src="js/bootstrap.min.js"></script>






	
</body>
</html>
