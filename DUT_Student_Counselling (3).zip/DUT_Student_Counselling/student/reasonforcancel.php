<?php if(!isset($_SESSION)){
	session_start();
	}  
?>


<?php include('uptomenu.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}



button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}


a{
	color: white;
}


input{
	color: black;
	width: 100px;
}
option{
	color: black;
}
select{
	color: black;
}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 36px;

}

form{
	
	text-align: left;
	width: 550px;
	border: none;
	border-color: #474e5d;
	height: 100%;
	background-color: dimgrey;
	align-self: center;
}

textarea{
	color: black;
	height: 200px;
	width: 223px;
}
</style>


		<div class="about-section">
			<br>
			<hr>
			<h1>Reason for Cancelling</h1>
			<hr>
			<br>

<?php
	include('../config.php');
		
		if(isset($_REQUEST['id'])){
		$id=$_REQUEST['id'];
		
		$sql = "SELECT * FROM booking WHERE `booking_id`='$id'";
		mysqli_query($conn, $sql);
		

							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
							    // output data of each row
							    while($row  = $result->fetch_assoc()) {
							        $dname   = $row["dname"];
							        $demail 	= $row["demail"];
							        $userid 	= $row["userid"];
							        $dcontact 	= $row["dcontact"];
							        $expertise 	= $row["expertise"];
							        $pname 	= $row["pname"];
							        $pcontact 	= $row["pcontact"];
							        $email 	= $row["email"];
							        $address 	= $row["address"];
							        $dates   = $row["dates"];
							        $tyme   = $row["tyme"];
							        $appoitmentType   = $row["appoitmentType"];
							       
						
							        
							        
							    }
							}
							
							$conn->close();

						}

					?>


	<!--Booking form-->



	
	

				<form action="" method="post" class="text-center form-group" >
					<label>
						Counsellor Name: <input type="text" name="dname" id="dname"value="<?php echo $dname; ?>" required >
					</label><br><br>					
					<label>
						  Email: <input type = "email" name="demail" id="demail" value="<?php echo $demail; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="userid" id="userid" value="<?php echo $userid; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="dcontact" id="dcontact" value="<?php echo $dcontact; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="expertise" id="expertise" value="<?php echo $expertise; ?>" required>
					</label>
					<label>
						<input type="hidden" name="pname" id="pname"value="<?php echo $pname; ?>" required >
					</label>
					<label>
						  <input type = "hidden" name="pcontact" id="pcontact" value="<?php echo $pcontact; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="email" id="email" value="<?php echo $email; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="address" id="address" value="<?php echo $address; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="dates" id="dates" value="<?php echo $dates; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="tyme" id="tyme" value="<?php echo $tyme; ?>" required>
					</label>
					<label>
						  <input type = "hidden" name="appoitmentType" id="appoitmentType" value="<?php echo $appoitmentType; ?>" required>
					</label>
					<label>
						  Reason: <textarea name="reason" id=""></textarea>
					</label><br><br>

					
					
					<button name="submit" type="submit" id="button" class="ripple2">Confirm</button> 
					<button id="button" class="ripple3"><a href="view_booking.php">Back</a></button><br><br>

				</form> 
<br><br>

			</div>
	
	
		</div>

		<?php

						include('../config.php');
						if(isset($_POST['submit'])){
							

						$sql = " INSERT INTO cancelled (dname,demail,userid,dcontact,expertise, pname,pcontact,email,address,dates,tyme,appoitmentType,reason)
							VALUES ('" . $_POST["dname"] . "','" . $_POST["demail"] . "','" . $_POST["userid"] . "','" . $_POST["dcontact"] . "','" . $_POST["expertise"] . "','" . $_POST["pname"] . "','". $_POST["pcontact"] . "','". $_POST["email"] . "','". $_POST["address"] . "','". $_POST["dates"] . "','". $_POST["tyme"] . "','". $_POST["appoitmentType"] . "' ,'". $_POST["reason"] . "' )";

							if ($conn->query($sql) === TRUE) {

									$sql = "DELETE FROM booking WHERE `booking_id`='$id'";
									mysqli_query($conn, $sql);
									echo "<script>alert('Your booking has been cancelled!');</script>";
									echo "<script>location.replace('view_booking.php');</script>";
								
							} else {
							    echo "<script>alert('There was an Error')<script>";
							}
							$conn->close();
						}
					?> 
				

	
	</div>
 <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>
