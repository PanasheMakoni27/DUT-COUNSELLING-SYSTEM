<?php session_start();  ?>
<?php include('uptomenu.php'); ?>

<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

form{
	text-align: left;
	width: 500px;
	background-color: #333;
}


textarea {
  color: black;
    }
:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
}

.container {
  margin: 50px auto;
}

ul {
  list-style: none;
  display: flex;
  width: 100%;
  padding: 0;
}

ul li {
  position: relative;
  color: white;
  width: 25%;
  text-align: center;
  background-color: #333;
}
 
ul li:before {

  display: flex;
  align-items: center;
  justify-content: center;
  
  content: attr(data-step);
   
  width: 40px;
  height: 40px;
  border-radius: 50%;
  
  background: white; 
  color: black;

  position: absolute;
  top: -50px;
  left: calc(50% - 20px);
  z-index: 99;
}

ul li:after {

  content: '';
  width: 100%;
  height: 5px;
  background: var(--light-grey);
  
  position: absolute;
  top: -35px;
  left: -50%;
}

ul li:first-child:after {
   width: 0;
}

ul li.active:before {
  background: var(--green);
  color: #fff;
}

ul li.active:after {
  background: var(--green);
}

ul li.active {
  color: var(--green);
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}

form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
input{
	color: black;
}

</style>

<div class="about-section">
	<hr>
  	<h1>Feedback and Queries</h1>
  	<hr>
	<table>
			
	<form action="" method="post" class="text-center form-group">
		<tr>
			<td>					
				<label>
					<span> Feedback:</span><textarea name="feedback" id="" cols="100" rows="15" required></textarea>
				</label>
			</td>
		</tr>
		<tr>
			<td>
				<button name="submit" type="submit" id="button" class="ripple2">Send</button> 
			</td>
		</tr>		


			<?php 
					
							include('../config.php');
							if(isset($_POST['submit'])){
							

							$sql = "INSERT INTO feedback (email,feedback)	VALUES ('" . $_SESSION["email"] ."','" . $_POST["feedback"] ."')";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>alert('Thank you, we appreciate your feedback!');</script>";
							} else {
							    echo "<script>alert('There was an Error')<script>";
							}

							$conn->close();
						}
					
 			?>


			</form> <br>&nbsp;&nbsp;&nbsp;
				
		</table>
				<br>

				
		
				
			</div>
		

	
	
</div>
<?php include('footer.php'); ?>


</body>
</html>
