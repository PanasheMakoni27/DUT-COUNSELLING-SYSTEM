<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('uptomenu.php'); ?>
<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}


body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  font-size: 20px;
}

.container {
	height: 0px;
  margin: 50px auto;
  color: #333;
}

ul {
  list-style: none;
  display: flex;
  width: 100%;
  padding: 0;
}

ul li {
  position: relative;
  color: white;
  width: 33.333333%;
  text-align: center;
  background-color: #474e5d;
  font-size: 20px;
}
 
ul li:before {

  display: flex;
  align-items: center;
  justify-content: center;
  
  content: attr(data-step);
   
  width: 40px;
  height: 40px;
  border-radius: 50%;
  
  background: white; 
  color: black;

  position: absolute;
  top: -50px;
  left: calc(50% - 20px);
  z-index: 99;
}

ul li:after {

  content: '';
  width: 100%;
  height: 5px;
  background: var(--light-grey);
  
  position: absolute;
  top: -35px;
  left: -50%;
}

ul li:first-child:after {
   width: 0;
}

ul li.active:before {
  background: var(--green);
  color: #fff;
}

ul li.active:after {
  background: var(--green);
}

ul li.active {
  color: var(--green);
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;

}

#leftbutton{
    background-color:#00cc00;
    color:#FAFAFA;
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 175px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;
}
th{
	text-align: center;
	max-width: 200px;
	font-size: 18px;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}
.item-align{
	align-items: flex-end;
}
</style>
	<div class="search" style="background-color:;">
		<div class="about-section">
			<hr>
			<h1>Select a Type of Session</h1>
			<hr>
			<br>
	<div class="container">
  <ul class="progressbar">
    <li data-step="1"class="active" >Select Type of Counselling</li>
    <li data-step="2"class="active">Select Counsellor</li>
    <li data-step="3">Booking</li>
  </ul>
</div>
<br>
<br>

	<div class="all_user" style="margin-top:0px; margin-left: 40px; ">
					<?php 
					include('../config.php');
					

					$sql = " SELECT * FROM counsellors WHERE expertise = '" . $_POST["expertise"]."' ";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count>=1){
						echo "<table border='1' align='center' cellpadding='32'>
							<tr>
								
								<th>Name</th>
								<th>Address</th>
								
								<th>Mobile</th>
								
								<th>Email</th>
								<th>Expertise in</th>
								<th>Book</th>
								
							</tr>";
						while($row=mysqli_fetch_array($result)){
								echo "<tr>";
					
								echo "<td>".$row['name']."<hr></td>";
								echo "<td>".$row['address']."<hr></td>";
								
								echo "<td>".$row['contact']."<hr></td>";
								echo "<td>".$row['email']."<hr></td>";

								echo "<td>".$row['expertise']."<hr></td>";
						?>
							<td><button id="button" class="ripple2"><a href="booking.php?cou_id=<?php echo $row['cou_id'] ?>">Book Now</a></button><hr></td>
						<?php 		
								
								echo "</tr>";
						}
						echo "</table>";
					} 
					else{
						print "<p align='center'>Sorry, there are currrently no registered counsellors for this type of counselling</p>";
					}

					?>
				</div>
			
<table>
	<tr>
		<td>
	<button id="next"><a href="search_consellor.php">Search Again</a></button>

</td>
</table>

	
	</div>
</div>

<?php include('footer.php'); ?>



	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>











	


