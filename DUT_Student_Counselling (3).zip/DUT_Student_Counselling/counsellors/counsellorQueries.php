<?php session_start();  ?>
<?php include('header.php'); ?>

<style type="text/css">
	
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}



button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}


a{
	color: white;
}


input{
	color: black;
	width: 100px;
}
option{
	color: black;
}
select{
	color: black;
}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 36px;

}

form{
	
	text-align: left;
	width: 550px;
	border: none;
	border-color: #474e5d;
	height: 100%;
	background-color: dimgrey;
	align-self: center;
}
</style>

<div class="about-section">
	<hr>
  	<h1>Request Change in My Details</h1>
  	<hr>
	
	<?php 
							include('../config.php');
							$sql="SELECT * FROM counsellors where userid='" . $_SESSION["userid"] . "'";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							
							$email=$data[4];
							
							mysqli_close($conn);
				?>		
	<form action="" method="post" class="text-center form-group">
		<br>
	<label>
				Email: <input type="email" name="email"  value="<?php echo $email; ?>" placeholder="email" required width="48" height="48">
</label><br><br>
<label>
				Query: <input type="text" name="feedback" id="" cols="100" rows="30"  placeholder="Enter which details you would like changed"required>

</label><br><br>

<button name="submit" type="submit" id="button" class="ripple2">Send</button> <br><br>

					
</form>

					<!-- User login validation -->
			<?php 
					
							include('../config.php');
							if(isset($_POST['submit'])){
							

							$sql = "INSERT INTO feedback (email,feedback)	
							VALUES ('" . $_POST["email"] ."','" . $_POST["feedback"] ."')";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>alert('Thanks, we will help as soon as possible!');</script>";
							} else {
							    echo "<script>alert('There was an Error')<script>";
							}

							$conn->close();
						}
					
 			?>


				 <br>
				<br>

				
		
				
			</div>
		

	
	
</div>
<?php include('footer.php'); ?>


</body>
</html>
