<?php if(!isset($_SESSION)){
	session_start();
	}  
?>


<?php include('header.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}



button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}


a{
	color: white;
}




.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 36px;

}



.textarea{
  width:200px;
  height:50px;
  border:1px solid white;
  color: black;
  background-color: white;
  pointer-events:none;
}

table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
  align-items: flex-start;
}


tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;
}
</style>


		<div class="about-section">
			<br>
			<hr>
			<h1>Meeting Notes</h1>
			<hr>
			<br>

<?php
	include('../config.php');
		
		if(isset($_REQUEST['id'])){
		$id=$_REQUEST['id'];
		
		$sql = "SELECT * FROM meet WHERE `meeting_id`='$id'";
		mysqli_query($conn, $sql);
		

							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
							    // output data of each row
							    while($row  = $result->fetch_assoc()) {
							   
							        $meetingnotes = $row["meetingnotes"];
							    }
							}
							
							$conn->close();

						}

					?>


	<!--Booking form-->



	
	


					
						<table>
							<tr>
								<td>
									<div class='textarea' contenteditable >
										<?php echo $meetingnotes; ?>

									</div>
									<div style="padding-right: 1000px; padding-top: 50px;">
										<button id="button" class="ripple3"><a href="pastAppointments.php">Back</a></button><br><br><br><br><br>
									</div>
							
								</td>
							</tr>
							
									
								

						</table>
						
						

					


<br><br>

			</div>
	
	
		</div>


				

	
	</div>
 <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>
