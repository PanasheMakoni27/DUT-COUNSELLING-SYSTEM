<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('header.php'); ?>
<style type="text/css">


	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;

}

#leftbutton{
    background-color:#00cc00;
    color:#FAFAFA;
}
table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
th{
	text-align: center;
	max-width: 200px;
	font-size: 18px;
}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;
}
a{
	color: white;
}
.item-align{
	align-items: flex-end;
}
</style>

<div class="about-section">
  <br>
  <hr><h1>Registered Students</h1><hr>
  <br>

	<div class="all_user" style="margin-top:0px; margin-left: 40px;">
				<?php 
					include('../config.php');

					$sql = " SELECT * FROM student ";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count>=1){
						echo "<table border='1' align='center' cellpadding='32'>
							<tr>
								<th>Student ID</th>
								<th>Student Name</th>
								
								<th>Age</th>
								<th>Mobile</th>
								<th>Address</th>
								<th>Gender</th>

								<th>Email </th>
							</tr>";
						while($row=mysqli_fetch_array($result)){
								echo "<tr>";
								echo "<td>".$row['id']."<hr></td>";
								echo "<td>".$row['name']."<hr></td>";
								
								echo "<td>".$row['age']."<hr></td>";
								echo "<td>".$row['contact']."<hr></td>";
								echo "<td>".$row['address']."<hr></td>";
								echo "<td>".$row['bgender']."<hr></td>";
								
								echo "<td>".$row['email']."<hr></td>";
								echo "</tr>";
						}
						echo "</table>";
					}
					else{
						print "<p align='center'>Sorry, No match found for your search result..!!!</p>";
					}

					?>
	</div>

			
</div>



<?php include('footer.php'); ?>

<script src="js/bootstrap.min.js"></script>
</body>
</html>





