<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;

}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 25px;

}

#leftbutton{
    background-color:#00cc00;
    color:#FAFAFA;
}
table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
th{
	text-align: center;
	max-width: 200px;
	font-size: 18px;
}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;
}
a{
	color: white;
}
.item-align{
	align-items: flex-end;
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  
  text-align: center;
  cursor: pointer;
}


</style>

<div class="about-section">
	<br>
	<hr>
	<h1>Past Appointments</h1>
	<hr>
	<br>

	<div class="all_user" style="margin-top:0px; margin-left: 40px; ">
				<?php 
					include('../config.php');

					$sql = " SELECT * FROM meet WHERE userid='".$_SESSION["userid"]."'";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count>=1){
						echo "<table border='1' align='center' cellpadding='32'>
							<tr>
								<th>Student Name</th>
								<th>Contact</th>
								<th>E-mail</th>
								<th>Date</th>
								<th>Time</th>
								<th>View Meeting Notes</th>
							</tr>";
						while($row=mysqli_fetch_array($result)){
							
								echo "<tr>";
								echo "<td>".$row['pname']."<hr></td>";
								echo "<td>".$row['pcontact']."<hr></td>";
								echo "<td>".$row['email']."<hr></td>";
								echo "<td>".$row['dates']."<hr></td>";
								echo "<td>".$row['tyme']."<hr></td>";
								
								

								echo "<td><button name = 'submit1' class='ripple2' id='button'><a href='viewNotes.php?id=".$row['meeting_id']."'><i class='far fa-file-alt'></i></a></button><hr></td>";					

								echo "</tr>";

						}
						echo "</table>";
					}
					else{
						print "<p align='center'>Sorry, there are no past appointments.</p>";
					}

					?>


					
	</div>

</div>
		

</div>
	
 <?php include('footer.php'); ?>
<script src="js/bootstrap.min.js"></script>	
</body>
</html>