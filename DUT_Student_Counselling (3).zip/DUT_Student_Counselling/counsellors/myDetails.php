<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php
					if(isset($_POST["submit"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:counsellorQueries.php?".$queryString);
        				die();
        			}
					?>
<?php include('header.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: dimgrey;
  opacity: 1;
  width: 400px;

}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  text-align: left;
  padding-left: 20px;
}

.card {
  color: black;
  background-color: #474e5d;
}


/* Add some padding inside the card container */
.container {
  padding: 2px 16px;
  background-color: #a9afbc;
}

#button{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
    width: 200px;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:13px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;


}

form{
	
	text-align: left;
	width: 550px;
	border: none;
	border-color: #474e5d;
	height: 100%;
	background-color: dimgrey;
	align-self: center;
}

input{
	color: black;
}
select{
	color: black;
}
option{
	color: black;
}

</style>
<!--Retrives Counsellors Information from database -->
				<?php 
							include('../config.php');
							$sql="SELECT * FROM counsellors where userid='" . $_SESSION["userid"] . "'";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							$name=$data[1];
							$address=$data[2];
							$contact=$data[3];
							$email=$data[4];
							$userid=$data[8];
							$expertise=$data[5];
							$pic = $data[7];

							mysqli_close($conn);
				?>


		<div class="about-section">
			<hr>
			<h1>My Details</h1>
			<hr>
	
<br>
				<form action="" method="post" class="text-center form-group" >
					<label>
						<input type="hidden" name="cou_id" value="<?php echo $cou_id; ?>" required >
					</label><br>
					<label>
						Counsellor Name: <input type="text" name="name" value="<?php echo $name; ?>" required >
					</label><br><br>
 					<label>
						Address: <input type="text" name="address" value="<?php echo $address; ?>" required >
					</label><br><br>
					<label>
						Contact: <input type="text" name="contact" value="<?php echo $contact; ?>" required >
					</label><br><br>
					<label>
						  Email: <input type = "email" name="email" value="<?php echo $email; ?>" required>
					</label><br><br>
					<label>
						User ID: <input type="text" name="userid" value="<?php echo $userid; ?>" placeholder="email" readonly="readonly">
					</label><br><br>
					<label>
						Expertise: <input type="text" name="expertise" value="<?php echo $expertise; ?>" placeholder="email" readonly="readonly">
					</label><br><br>
					<br>

                                        <button name="submit" type="submit" class="ripple2" id="button">Request Details Change</button><br><br>
				</form>


<br>
</div>
</div>



			
<script src="js/bootstrap.min.js"></script>
</body>
</html>