<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>

<style type="text/css">
	
		.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  width: 100%;
}

table{
  align-items:center;
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;

}

th{
  text-align: center;
  max-width: 200px;
  font-size: 18px;
}
input{
	height: 10px;
	padding-left: 1px;
}

button{
	border: none;
	border-radius: 1px;
	height: 25px;
	width: 25px;
	padding-left: 1px;
	
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.2s;
  width: 100%;
  color: black;
  background-color: white;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,1.0);
}

.container {
  padding: 2px 16px;
  padding-top: 5px;
  padding-left: 10px;
  padding-bottom: 10px;
}

</style>


<div class="about-section">
<br>
<hr><h1>My Dashboard</h1><hr>
<br>


<div class="about-section">

<hr><h1>Upcoming Appoinments</h1><hr>
<br>

      <?php 
          include('../config.php');

          $sql = " SELECT * FROM booking WHERE userid='".$_SESSION["userid"]."' ORDER BY dates ASC LIMIT 3";
          $result = mysqli_query($conn,$sql);
          $count = mysqli_num_rows($result);

          if($count>=1){
            while($row  = $result->fetch_assoc()) {               

            echo"<div class='card'>";
            echo"<div class='container'>";
            echo"<h3><b>Upcoming Appointments</b></h3>";
            echo"<p><h4>You have an upcoming <b>".$row['appoitmentType']."</b> appointment with <b>".$row['pname']."</b> scheduled for <b>".$row['dates']."</b> at <b>".$row['tyme']."</b></h4></p>";
            echo"</div>";
            echo"</div>";
          }
              }
else{

echo'<div class="card">';
echo' <div class="container">';
echo'  <h4><b>Upcoming Appointments</b></h4> ';
echo'   <p>You have no upcoming appointments</p> ';
echo'  </div>';
echo'</div>';

}
              
      $conn->close();
        
?>

<br>
<hr><h1>Cancelled Appoinments</h1><hr>
<br>
<?php
	include('../config.php');
		
		$sql = "SELECT * FROM cancelled WHERE userid ='".$_SESSION["userid"]."' ORDER BY cancelled_id DESC LIMIT 3";
		mysqli_query($conn, $sql);

		$result = $conn->query($sql);

		$count = mysqli_num_rows($result);

        if($count>=1){
		
		while($row  = $result->fetch_assoc()) {						    

            echo"<div class='card'>";
            echo"<div class='container'>";
            echo"<h3><b>Upcoming Appointments</b></h3>";
            echo"<p><h4><b>".$row['pname']."</b> has cancelled an upcoming <b>".$row['appoitmentType']."</b> appoinment, that was scheduled for <b>".$row['dates']."</b> at <b>".$row['tyme']."</b> <br>Reason: <b>".$row['reason']."</b> </h4></p>";
            echo"</div>";
            echo"</div>";
          }
							}
else{

echo'<div class="card">';
echo' <div class="container">';
echo'  <h4><b>Upcoming Appointments</b></h4> ';
echo'   <p>You have no upcoming appointments</p> ';
echo'  </div>';
echo'</div>';

}
							
			$conn->close();


        
?>




</div>
</div>


<?php include('footer.php'); ?>


<script src="js/bootstrap.min.js"></script>
</body>
</html>
