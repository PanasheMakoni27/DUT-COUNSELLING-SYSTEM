<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php
					if(isset($_POST["submit1"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:../Zoom_Meeting/index.php?".$queryString);
        				die();

        			}
?>
<?php include('header.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

	.join-section {
  padding-left: 450px;
  text-align: center;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
  width: 800px;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}



button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}


a{
	color: white;
}




.ripple1{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;
  height: 36px;
  width: 250px;

}
.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;
  height: 36px;


}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 36px;

}









/* This allow me to have the full width of the page without the initial padding/margin*/
body, html {
  margin:0;
  padding:0;
  height: 100%;
  width:100%;
  font-family:Acme;
  min-width:700px;
}

.splitdiv{
  height:100%;
  width:50%;
}

/* This part contains all of the left side of the screen */
/* ----------------------------------------- */
#leftdiv{
  float:left;
  background-color:#ddd;
  height: 600px;
}
#leftdivcard{
  margin:0 auto;
  width:610px;
  height: 550px;
  background-color: rgba(0, 0, 0, 0.0);
  margin-top: 50vh; 
  transform: translateY(-50%);
  font-size: 18px;
  border-radius:5px
}


#rightdiv{
  float:right;
  background-color:#333;
  height: 600px;
}

#rightdivcard{
  margin:0 auto;
  width:50%;
  height: 171px;
  margin-top: 50vh;
  transform: translateY(-50%);
  padding-left: 0px;
  padding-bottom: 650px;  
}


#rightbutton{
    background-color:#FFFFFF;
    border-radius:5px;
    color:#00cc00;
}
/* ----------------------------------------- */

/* Basic styling */
/* ----------------------------------------- */


input{
  font-family:Acme;
  font-size:16px;
}

input{
  width:85%;
  height:40px;
  padding:10px;
  margin-left:2%;
  margin-right:2%;
  margin-top:10px;
  margin-bottom:10px;
  display:inline-block;
  background-color:#FAFAFA;
  border:none;
  font-family: 'Quicksand', sans-serif;
  color: black;
}

input:focus {
    outline: none !important;
    border:1px solid #4ECDC4;
    box-shadow: 0 0 5px #719ECE;
}
label{
	color: black;
}

textarea{
	height: 500px;
	width: 300px;
	color: black;
}


table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
th{
	text-align: center;
	max-width: 200px;
	font-size: 18px;
}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;
  align-items: center;
}
h3{
	align-items: flex-start;
	width: 300px;
}
</style>

		<div class="about-section">
			<br>
			<hr>
			<h1>Appointment Details</h1>
			<hr>
			<br>

<?php
	include('../config.php');
		
	if(isset($_REQUEST['id'])){
		$id=$_REQUEST['id'];
		
		$sql = "SELECT * FROM booking WHERE `booking_id`='$id'";

		mysqli_query($conn, $sql);
		

							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
							    // output data of each row
							    while($row  = $result->fetch_assoc()) {
							        
											$dname   = $row["dname"];
							        $demail 	= $row["demail"];
							        $userid 	= $row["userid"];
							        $dcontact 	= $row["dcontact"];
							        $expertise 	= $row["expertise"];
							        $pname 	= $row["pname"];
							        $pcontact 	= $row["pcontact"];
							        $email 	= $row["email"];
							        $address 	= $row["address"];
							        $dates   = $row["dates"];
							        $tyme   = $row["tyme"];
							        $appoitmentType   = $row["appoitmentType"];

									if ($row['appoitmentType'] == 'Online') {
							
						
									echo'<form action="" method="post" class="text-center">
									<div class="join-section">
									<hr><button name="submit1" type="submit" id="button" class="ripple1">Start Online Session</button><hr>
									</div>
									</form>';
							}


							    }
							}
							
							$conn->close();

						}

					?>


	<!--Booking form-->




				<form action="" method="post" class="text-center form-group" >

					<div style="height:100%;width:100%;display:inline-block">
						<div class="splitdiv" id="leftdiv">
      				<div id="leftdivcard">

      							<label><input type="hidden" name="dname" id="dname"value="<?php echo $dname; ?>" required ></label>				
										<label><input type = "hidden" name="demail" id="demail" value="<?php echo $demail; ?>" required></label>
										<label><input type = "hidden" name="userid" id="userid" value="<?php echo $userid; ?>" required></label>
										<label><input type = "hidden" name="dcontact" id="dcontact" value="<?php echo $dcontact; ?>" required></label>
										<label><input type = "hidden" name="expertise" id="expertise" value="<?php echo $expertise; ?>" required></label>
										<label><input type = "hidden" name="address" id="address" value="<?php echo $address; ?>" required></label>
										<label><input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>" required >
					<label>
						Student Name: <input type="text" name="pname" value="<?php echo $pname; ?>" required >
					</label><br><br>
 					<label>
						Student Email: <input type="email" name="email" value="<?php echo $email; ?>" required >
					</label><br><br>
					<label>
						Student Contact: <input type="text" name="pcontact" value="<?php echo $pcontact; ?>" required >
					</label><br><br>
					<label>
						  Meeting Date: <input type = "text" name="dates" value="<?php echo $dates; ?>" required>
					</label><br><br>
					<label>
						Meeting Time: <input type="text" name="tyme" value="<?php echo $tyme; ?>" readonly="readonly">
					</label><br><br>
					<label>
						Meeting Type: <input type="text" name="appoitmentType" value="<?php echo $appoitmentType; ?>" readonly="readonly">
					</label><br><br>

					<button name="submit" type="submit" id="button" class="ripple2">Finish</button>
					<button id="button" class="ripple3"><a href="myAppoinment.php">Cancel</a></button><br><br>
				</div>
			</div>
			<div class="splitdiv" id="rightdiv">
      <div id="rightdivcard">
      	<table>
      		<tr>
      			<td>
      		<h3>Meeting Notes</h3>
      	<textarea name="meetingnotes" id="meetingnotes" required></textarea>
      </td>
      </tr>
      	</table>
      		
      	</div>
      </div>
     </form> 


			</div>
	
	
		</div>
				
		<?php

						include('../config.php');
						if(isset($_POST['submit'])){
							

						$sql = " INSERT INTO meet (dname,demail,userid,dcontact,expertise, pname,pcontact,email,address,dates,tyme,appoitmentType,meetingnotes)
							VALUES ('" . $_POST["dname"] . "','" . $_POST["demail"] . "','" . $_POST["userid"] . "','" . $_POST["dcontact"] . "','" . $_POST["expertise"] . "','" . $_POST["pname"] . "','". $_POST["pcontact"] . "','". $_POST["email"] . "','". $_POST["address"] . "','". $_POST["dates"] . "','". $_POST["tyme"] . "','". $_POST["appoitmentType"] . "' ,'". $_POST["meetingnotes"] . "' )";

							if ($conn->query($sql) === TRUE) {

									$sql = "DELETE FROM booking WHERE `booking_id`='$id'";
									mysqli_query($conn, $sql);
									echo "<script>alert('Your session is complete!');</script>";
									echo "<script>location.replace('myAppoinment.php');</script>";
								
							} else {
							    echo "<script>alert('There was an Error')<script>";
							}
							$conn->close();
						}
					?> 
	
	</div>
 <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>
