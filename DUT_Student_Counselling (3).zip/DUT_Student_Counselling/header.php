<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>STUDENT COUNSELING CENTRE</title>
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
	<meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="stylec.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
	<style>
		.error {color: #FF0000;}

		/* Create a top navigation bar with a black background color  */
		.topnav {
  	background-color: #333;
  	overflow: hidden;
    border: 2px solid #00cc00;
    top: 0;
 
    width: 100%;
		}

		/* Style the links inside the navigation bar */
	.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 18px;

}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create a right-aligned (split) link inside the navigation bar */
.topnav a.split {
  float: right;
  background-color: rgb(0, 204, 0, 1.0);
  color: white;

}

.fixed {
    position:fixed;
    top:0;
    left:0;
    right:0;
    z-index:99;
}

</style>
</head>
<body>

<div class="fixed">
	<div class="topnav">
	<a href="index.php"><img src="photo/dutLogo.png" alt="" width = "19px" height = "19px"></a>
  <!--<a href="index.php"><i class="fa fa-fw fa-home"></i>Home</a>-->
  <a href="HealthInfo.php"><i class="fas fa-heartbeat"></i>Health and Well-Being</a>
  <a href="about.php"><i class="fas fa-users"></i>About Us</a>
  <a href="help.php"><i class="  fa fa-question-circle"></i>Help</a>
  <a href="signin.php" class="split"><i class="fa fa-fw fa-user"></i>Login</a>
  
</div>
</div>

   
</body>


