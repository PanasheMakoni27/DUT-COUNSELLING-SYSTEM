<?php session_start();  ?>
<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Student Counselling Counsellor</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../style.css">
	<style>
		.error {color: #FF0000;}

			.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
}


#leftbutton1{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}
table{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  
  color: white;
}
form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
	</style>
</head>
<body>

<div class="container-fluid">

<div class="about-section">
  <br>
  <hr><h1>Counsellor Login</h1><hr>

  <table>
  	<tr>
  		<td>
			<form action="" method="post" class="text-center">
				<label>
					Staff Number:<input type="text" name="userid"  placeholder="Staff Number" required>
				</label><br><br>
				<label>
					Password:<input type="password" name="password"  placeholder="password" required>
				</label><br><br>
				<button name="submit" type="submit" id="leftbutton1" class="ripple2">Login</button> <br>

					


			<!--Validating counsellors login details-->
			<?php 
							$_SESSION['adminstatus']="";
							
							include('config.php');
							if(isset($_POST["submit"])){
                                                        $password = $_POST['password'];

                                                        $hash = sha1($password);
							//$sql= "SELECT * FROM counsellors WHERE userid= '" . $_POST["userid"]."' AND password= '" . $_POST["password"]."'";
                                                        
                                                        $sql= "SELECT * FROM counsellors WHERE userid= '" . $_POST["userid"]."' AND password= '$hash' LIMIT 1";
                                                        
							$result = $conn->query($sql);

									if ($result->num_rows > 0) {
											$_SESSION["userid"]= $_POST["userid"];
											// $_SESSION["type"]=$result[2];
											$_SESSION['adminstatus']= "yes";
										    echo "<script>location.replace('counsellors/counsellordashboard.php');</script>";
												// echo "u are supposed to redirect to ur profile";
										} else {
										    echo "<span style='color:red;'>Incorrect username or password</span>";
										}
						$conn->close();		
					}
					
 			?>

			</form>
			</td>
			</tr>
			</table> <br>&nbsp;&nbsp;&nbsp;
                        <br><br><br><br><br>
		</div>
	
</div>
</div>
</div>
	
<?php include('footer.php'); ?>
	


<script src="../js/bootstrap.min.js"></script>	
</body>
</html>

