<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php
					if(isset($_POST["submit"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:queries.php?".$queryString);
        				die();

        			}
        			if(isset($_POST["submit1"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:form.php?".$queryString);
        				die();

        			}
?>
<?php include('header.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
/*form{
	text-align: left;
	width: 500px;
	background-color: #474e5d;
}*/
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}
:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;

}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  padding-left: 10px;
  width: 300px;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  text-align: left;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}


input{
	color: black;
}
option{
	color: black;
}
select{
	color: black;
}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: black;
  color: white;
  height: 36px;

}

.ripple{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;
  height: 36px;

}

input{
	width: 100px;
}
 

.base {
	 display: flex;
	 justify-content: center;
	 height: 100vh;
	 align-items: center;
	 background: #00afda;
}
 .mail-info {
	 display: flex;
	 justify-content: center;
	 align-items: center;
	 cursor: pointer;
	 padding: 16px 36px;
	 border-radius: 5px;
	 background: white;

	 color: black;
}

 .mail-text {
	 font-size: 18px;
	 
}
 [tooltip] {
	 position: relative;
	 width: 230px;
	 text-align: center;
         
	 
}
 [tooltip]::before {
	 content: "";
	 position: absolute;
	 top: -6px;
	 left: 50%;
	 transform: translateX(-50%);
	 border-width: 4px 6px 0 6px;
	 border-style: solid;
	 border-color: #fff transparent transparent transparent;
	 z-index: 100;
	 opacity: 0;
	 transition: all 250ms ease;
}
 [tooltip]::after {
	 content: attr(tooltip);
	 position: absolute;
	 left: 50%;
	 top: -6px;
	 transform: translateX(-50%) translateY(-100%);
	 background: #fff;
	 text-align: center;
	 color: #00afda;
	 padding: 4px 8px;
	 font-size: 14px;
	 min-width: 80px;
	 border-radius: 4px;
	 pointer-events: none;
	 opacity: 0;
	 transition: all 250ms ease;
}
 [tooltip-position ='bottom']::before {
	 top: 100%;
	 margin-top: 36px;
	 transform: translateX(-50%) translatey(-100%) rotate(-180deg);
}
 [tooltip-position='bottom']::after {
	 top: 100%;
	 margin-top: 36px;
	 transform: translateX(-50%) translateY(0);
}
 [tooltip]:hover::after, [tooltip]:hover::before {
	 opacity: 1;
         
}

form{
	
	text-align: left;
	width: 400px;
	border: none;
	border-color: #474e5d;
	height: 100%;
	background-color: rgba(0,0,0,0.0);
	align-self: center;
	align-items: center;
	padding-left: 10px;
}
.textarea{
  width:300px;
  height:300px;
  border:1px solid white;
  border-radius: 5px;
  color: black;
  background-color: white;
  pointer-events:none;
  text-align: left;
  font-size: 16px;
  justify-content: space-between;
  padding-left: 10px;
  padding-top: 10px;
}
</style>

<div class="search" >
		<div class="about-section">
			<hr>
			<h1>Query Details</h1>
			<hr>
			<br>


<?php 
	$id = isset($_GET['id'])?$_GET['id']:"";

 ?>
				<!-- Here we are fetching counsellors info -->
					<?php 
							include('../config.php');
							
							$sql="SELECT * FROM feedback WHERE id = $id ";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							$doc_id=$data[0];
							$email=$data[1];
							$feedback=$data[2];
							
							

							mysqli_close($conn);
				?>



				<form action="" method="post" class="text-center form-group" >
					<table>
					<tr>
						<td>
					<label>
						
                                            <h4> Email:</h4>
						  	<span class="mail-info">
							<span class="mail-text" tooltip="Click to Copy" tooltip-position="bottom"><?php echo $email; ?>
							<i class="fa fa-clone" style="font-size:10px"></i>
							</span>
							
							</span>
							<input type="hidden" name="email" value="<?php echo $email; ?>">
						 
					</label>
				</td>
			</tr>
			<tr>
				<td>
					
				
                                    <h4>Query:</h4>
					<!--<label>
						<h3>Query: <textarea><?php echo $feedback; ?></textarea></h3>
					</label><br><br>-->


					<div class='textarea' contenteditable>
						<?php echo $feedback; ?>
					</div>
					<input type="hidden" name="email" value="<?php echo $feedback; ?>">
				</td>
			</tr>
			<tr>
				<td>
					<button name="submit1" type="submit" id="button" class="ripple">Respond</button> 

					
					<button name="submit" type="submit" id="button" class="ripple3">Back</button> 
				</td>
			</tr>
				</table>

				</form> 




			</div>




				




	</div>
 <?php include('footer.php'); ?>


	
	</div>
<script type="text/javascript">

const copyMailId = document.querySelectorAll('.mail-text');

copyMailId.forEach(copyText => {
    copyText.addEventListener('click', () => {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(copyText);
        selection.removeAllRanges();
        selection.addRange(range);

        try {
            document.execCommand('copy');
            selection.removeAllRanges();

            const mailId = copyText.textContent;
            copyText.textContent = 'Copied!';
            copyText.classList.add('success');

            setTimeout(() => {
                copyText.textContent = mailId;
                copyText.classList.remove('success');
            }, 1000);
        } catch (e) {
            copyText.textContent = 'Couldn\'t copy, hit Ctrl+C!';
            copyText.classList.add('error');

            setTimeout(() => {
                errorMsg.classList.remove('show');
            }, 1200);
        }
    });
});

</script>
	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>