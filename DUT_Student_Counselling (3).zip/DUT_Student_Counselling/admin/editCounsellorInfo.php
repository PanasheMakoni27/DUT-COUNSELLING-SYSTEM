<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('header.php'); ?>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}



button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}


a{
	color: white;
}


input{
	color: black;
	width: 100px;
}
option{
	color: black;
}
select{
	color: black;
}

.ripple3{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:14px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: gray;
  color: white;
  height: 36px;

}

form{
	
	text-align: left;
	width: 550px;
	border: none;
	border-color: #474e5d;
	height: 100%;
	background-color: dimgrey;
	align-self: center;
}

</style>

<br>
		<div class="about-section">
			<br>
			<hr>
			<h1>Edit Counsellor Details</h1>
			<hr>
			<br>


<?php 
	$cou_id = isset($_GET['cou_id'])?$_GET['cou_id']:"";

 ?>
				<!-- Here we are fetching counsellors info -->
					<?php 
							include('../config.php');
							
							$sql="SELECT * FROM counsellors WHERE cou_id = $cou_id ";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							$cou_id=$data[0];
							$name=$data[1];
							$address=$data[2];
							$contact=$data[3];
							$email=$data[4];
							$userid=$data[8];
							$expertise=$data[5];
							

							mysqli_close($conn);
				?>


	<!--Booking form-->



	
	

				<form action="" method="post" class="text-center form-group" >
					<label>
						<input type="hidden" name="cou_id" value="<?php echo $cou_id; ?>" required >
					</label><br>
					<label>
						Counsellor Name: <input type="text" name="name" value="<?php echo $name; ?>" required >
					</label><br><br>
 					<label>
						Address: <input type="text" name="address" value="<?php echo $address; ?>" required >
					</label><br><br>
					<label>
						Contact: <input type="text" name="contact" value="<?php echo $contact; ?>" required >
					</label><br><br>
					<label>
						  Email: <input type = "email" name="email" value="<?php echo $email; ?>" required>
					</label><br><br>
					<label>
						User ID: <input type="text" name="userid" value="<?php echo $userid; ?>" placeholder="email" readonly="readonly">
					</label><br><br>
					<label>
						Expertise: 
						 <select name="expertise" required >
								<option>-Select expertise-</option>
								<option>Individual Counselling </option>
								<option>Career Counselling</option>
								<option>Academic Counselling</option>
								<option>Religious Counselling</option>
							</select>
					</label><br><br>
					
					
                                        <button name="submit" type="submit" id="button" class="ripple2" style="height:36px">Confirm</button> 
					<button id="button" class="ripple3"><a href="editCounsellor.php">Cancel</a></button><br><br>

				</form> 
<br><br>

			</div>
	
	
		</div>
				
			<!-- confirming appointment booking -->

			<?php

						include('../config.php');
						if(isset($_POST['submit'])){
							

							$sql="
							UPDATE counsellors

							SET 
									name='" .$_POST["name"]. "' ,
									address='" .$_POST["address"]."' , 
									contact='" .$_POST["contact"]. "',
									email='" .$_POST["email"]. "', 
									userid='" .$_POST["userid"]. "',
									expertise='" .$_POST["expertise"]. "' 

							WHERE userid='" . $_POST["userid"] . "'";

		
							if (mysqli_query($conn, $sql)) {
						    echo "<script>alert(' Record updated successfully');</script>";
							echo "<script>location.replace('editCounsellor.php');</script>";
							} else {
							    echo "<script>alert('There was a Error Updating profile');</script>";
							}

						mysqli_close($conn);
													}
					?> 
	
	</div>
 <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>
