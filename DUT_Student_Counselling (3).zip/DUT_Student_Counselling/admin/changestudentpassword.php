<?php if(!isset($_SESSION)){
	session_start();
	}  
?>


<?php include('header.php'); ?>

<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

form{
	text-align: left;
	width: 500px;
	background-color: #333;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
}

.container {
  margin: 50px auto;
}

ul {
  list-style: none;
  display: flex;
  width: 100%;
  padding: 0;
}

ul li {
  position: relative;
  color: white;
  width: 25%;
  text-align: center;
  background-color: #333;
}
 
ul li:before {

  display: flex;
  align-items: center;
  justify-content: center;
  
  content: attr(data-step);
   
  width: 40px;
  height: 40px;
  border-radius: 50%;
  
  background: white; 
  color: black;

  position: absolute;
  top: -50px;
  left: calc(50% - 20px);
  z-index: 99;
}

ul li:after {

  content: '';
  width: 100%;
  height: 5px;
  background: var(--light-grey);
  
  position: absolute;
  top: -35px;
  left: -50%;
}

ul li:first-child:after {
   width: 0;
}

ul li.active:before {
  background: var(--green);
  color: #fff;
}

ul li.active:after {
  background: var(--green);
}

ul li.active {
  color: var(--green);
}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}

form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
input{
	color: black;
}

</style>
<br>
		<div class="about-section">
			<br>
			<hr>
			<h1>Enter Student Email to Begin</h1>
			<hr>
			<br>
			<br>
		
			<table>
				<tr>
					<td>
				<form action="" method="post" class="text-center">
					<label>
						Student Email:<input type="email" name="email"  placeholder="Enter Student Email" required>
					</label><br><br>

					<button name="submit" type="submit" id="button" class="ripple2">Proceed</button> <br>



								<?php 
					$_SESSION['student']="";
							
							include('config.php');
							if(isset($_POST["submit"])){


							$sql= "SELECT * FROM student WHERE email= '" . $_POST["email"]."' ";

							$result = $conn->query($sql);

									if ($result->num_rows > 0) {
											$_SESSION["email"]= $_POST["email"];
											$_SESSION['student']= "yes";
										    echo "<script>location.replace('changestudentpassword1.php');</script>";
												
										} else {
										    echo "<span style='color:red;'>Invalid username or password</span>";
										}
						$conn->close();		
					}
					
 			?>
				</form>

			</td>
		</tr>
		</table>

				 <br>&nbsp;&nbsp;&nbsp;
				

				<br>

				
		
				
			
		
	</div>
		
		
			
		
	</div>
	
	

	
  <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>
	<script src='https://meet.jit.si/external_api.js'></script>


 
			



	
</body>
</html>
