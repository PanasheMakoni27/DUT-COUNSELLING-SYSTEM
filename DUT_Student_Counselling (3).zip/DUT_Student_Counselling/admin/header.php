<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>DUT STUDENT COUNSELLING CENTER ADIMIN</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
	
<style>
		.error {color: #FF0000;}

		.topnav {
  	background-color: #333;
  	overflow: hidden;
   border: 2px solid #00cc00;
    top: 0;
 
    width: 100%;
		}

		/* Style the links inside the navigation bar */
	.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 18px;
  font-family: Quicksand;
  font-weight: normal;

}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create a right-aligned (split) link inside the navigation bar */
.topnav a.split {
  float: right;
  background-color: #00cc00;
  color: white;

}

.fixed {
    position:fixed;
    top:0;
    left:0;
    right:0;
    z-index:99;
}


	</style>
</head>
<body>

<?php
	if($_SESSION['adminstatus'] == ""){
			header("location:index.php");
	}
?>



	<div class="fixed">
	<div class="topnav">
	<a href="adminDashboard.php"><img src="dutLogo.png" alt="" width = "18px" height = "18x"></a><!-- Add a home page -->
  <a href="adminDashboard.php"><i class=" fas fa-tachometer-alt"></i> Dashboard</a>
  <a href="counsellors.php"><i class="fas fa-user-md"></i> Counsellors</a>
  <a href="students.php"><i class="fas fa-users"></i> Students</a>
  <a href="queries.php"><i class="fas fa-comments"></i> Queries</a>
  <a href="index.php" class="split"><i class="fas fa-sign-out-alt"></i> Logout</a>
  
</div>
</div>



	

