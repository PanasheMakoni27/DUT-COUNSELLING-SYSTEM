<?php session_start();  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Student Counselling Counsellor</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
	<style>
		.error {color: #FF0000;}



					.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
}


#leftbutton1{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}

	/* Create a top navigation bar with a black background color  */
		.topnav {
  	background-color: #333;
  	overflow: hidden;
    border: 2px solid #00cc00;
    top: 0;
 
    width: 100%;
		}

		/* Style the links inside the navigation bar */
	.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 18px;
  font-family: Quicksand;
  font-weight: normal;

}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create a right-aligned (split) link inside the navigation bar */
.topnav a.split {
  float: right;
  background-color: #00cc00;
  color: white;

}

.fixed {
    position:fixed;
    top:0;
    left:0;
    right:0;
    z-index:99;
}

table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;

}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;

  color: white;
}

form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
	</style>
</head>
<body>

	<div class="fixed">
	<div class="topnav">
	<a href="index.php"><img src="dutLogo.png" alt="" width = "18px" height = "18x"></a>
  <a href="index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a><!-- Consider dropdowns for this...-->
  <a href="../counsellorsLogin.php"><i class="fas fa-users"></i>Counsellors</a> <!-- Include this in the dropdown-->
  <a href="../signin.php"><i class="fas fa-users"></i>Students</a>
  <a href="../index.php" class="split"><i class="fas fa-sign-in-alt"></i> Login</a>
  
</div>
</div>

	<div class="about-section">
  <br>
  <hr><h1>Admin Login</h1><hr>
  <br>
<br>
<table>
	<tr>
		<td>
			<form action="" method="post" class="text-center">
				<label>
					Username:<input type="text" name="username"  placeholder="username" required style="margin-right: 75px; color: black">
				</label><br><br>
				<label>
					Password: <input type="password" name="password"  placeholder="password" required style="margin-right: 75px; color: black">
				</label><br><br><br>
					<button name="submit" type="submit" id="leftbutton1" class="ripple2">Login</button><br>

					

					<!--Validating Login-->
			    <?php 
							$_SESSION['adminstatus']="";
							include('../config.php');
							if(isset($_POST["submit"])){
                                                            
                                                            
                                                        $password = $_POST['password'];

                                                        $hash = sha1($password);
                
                                                        //$q = $db->query("SELECT * FROM admin WHERE username = '$username' AND password = '$hash' LIMIT 1 ");
                                                        //END
							//$sql= "SELECT * FROM student WHERE email= '" . $_POST["email"]."' AND password= '$hash' LIMIT 1 ";
    

							$sql= "SELECT * FROM users WHERE username= '" . $_POST["username"]."' AND password= '$hash' LIMIT 1";

							$result = $conn->query($sql);

									if ($result->num_rows > 0) {
											$_SESSION["username"]= $_POST["username"];
											
											$_SESSION['adminstatus']= "yes";
										    echo "<script>location.replace('adminDashboard.php');</script>";
												// echo "u are supposed to redirect to ur profile";
										} else {
										    echo "<span style='color:red;'>Invalid username or password</span>";
										}
						$conn->close();		
					}
					
 				?>



			</form>
			</td></tr></table>
			 <br>
		</div>
	
	
</div>
<?php include('footer.php'); ?>
<script src="js/bootstrap.min.js"></script>

</body>
</html>

