<footer>
<style>
	.footer {
  	position: static;
  	left: 0;
  	bottom: 0;
  	height: 50px;
  	width: 100%;
  	background-color:  #333;
  	color: white;
  	text-align: center;
}
</style>

<div class="footer">
<span style="color: white;font-family: Quicksand ;font-size: 20px">&copy;<?php echo date('Y'); ?>-All Rights Reserved by Admin</span>
</div>
</footer>


