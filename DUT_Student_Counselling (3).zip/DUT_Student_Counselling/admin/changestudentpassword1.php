<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>
<style>
/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
</style>

<style type="text/css">
	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

form{
	text-align: left;
	width: 500px;
	background-color: #333;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
}

.container {
  margin: 50px auto;
}


button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
	align-items:center;
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
h3{
	color: white;
}
img{
	background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
	color: white;
}

form{
	padding: 100px;
	width: 100%;
	height: 100%;
	background-color: dimgrey;
}
input{
	color: black;
}

</style>

				<?php 
							include('../config.php');
							
							$sql="SELECT * FROM student where email='" . $_SESSION["email"] . "'";
			
							$q=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($q);
							
							$data=mysqli_fetch_array($q);
							$email=$data[6];
							//$password = $data[7];
                                                        //SABELO NEW PASSWORD
                                                        $password="'$data[7]' LIMIT 1 ";
                                                        //NEW PASSWORD END

							mysqli_close($conn);
				?>


<br>
		<div class="about-section">
			<br>
			<hr>
			<h1>Change Password</h1>
			<hr>
			<br>
		
			<table>
				<tr>
					<td>
				<form action="" method="post" class="text-center">
					<label>
						Student Email:<input type="email" name="email"  value="<?php echo $email; ?>" required>
					</label><br><br>
					<label>
						New Password:<input type="password" id="psw" name="newpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Check the format below. Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="New password" required>
					</label><br><br>
					<label>
						Confirm Password:<input type="password" name="confpassword"  placeholder="Confirm password" required>
					</label><br><br>
					<button name="submit" type="submit" id="button" class="ripple2">Change Password</button> 

								<?php 
					
							
							include('../config.php');
							if(isset($_POST["submit"])){
							

							$sql= "SELECT * FROM student WHERE email= '" . $_SESSION["email"]."'";

							$query=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($query);

							if($row>0){
								//check the new password
                                                                //SABELO ADDED!
                                                                $newpassword = $_POST['newpassword'];
                                                                $confpassword=$_POST['confpassword'];
								if($newpassword==$confpassword){
                                                                    
								//OLD
								//$sql1="UPDATE student SET password='" . $_POST["newpassword"]  ."' WHERE email='" .$_SESSION["email"] ."'";
								
                                                                //NEW START
                                                                //$newpassword = $_POST['newpassword'];
                                                                $hash = sha1($newpassword);
                                                                $sql1="UPDATE student SET password='" . $hash  ."' WHERE email='" .$_SESSION["email"] ."'";
                                                                //NEW END
                                                                mysqli_query($conn,$sql1);
								mysqli_close($conn);
								echo "<script>alert('Password Has been changed');</script>";
								echo "<script>location.replace('students.php');</script>";
								}
								else{
									echo "<script>alert('Password did not match');</script>";
									
								}


							}else{
								echo "<script>alert('Input Correct Password');</script>";
							}
									
										
								
					}
					
 			?>
				</form>


	
			</td>
		</tr>
		</table>
		

				 <br>&nbsp;&nbsp;&nbsp;

				<br>	
	</div>
	</div>
		</div>
			<div id="message">
		<h3 style="color:black;">Password must contain the following:</h3>
		<p id="letter" class="invalid">A <b>lowercase</b> letter</p>
		<p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
		<p id="number" class="invalid">A <b>number</b></p>
		<p id="length" class="invalid">Minimum <b>8 characters</b></p>
		</div>
	  </div>	
		
			
		
	</div>
	<script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
	
	

	
  <?php include('footer.php'); ?>


	
	</div>




	<script src="js/bootstrap.min.js"></script>
	<script src='https://meet.jit.si/external_api.js'></script>


 
			



	
</body>
</html>
