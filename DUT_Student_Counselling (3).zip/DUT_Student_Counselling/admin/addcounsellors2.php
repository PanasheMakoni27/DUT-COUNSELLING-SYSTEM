<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>
<style>
/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
</style>

<style type="text/css">
		.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  width: 100%;
}

#leftbutton{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}

#button{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}
form{
	
	text-align: left;
	width: 550px;
	border: none;
	border-color: #474e5d;
	height: 100%;
	background-color: dimgrey;
	align-self: center;
}
label{
	color: white;
}

</style>

<div class="search" style="background-color:;">
		<div class="about-section">
			<br>
			<hr>
			<h1>Register New Counsellor</h1>
			<hr>
			<br>




				 <form enctype="multipart/form-data" action=""  method="post" class="text-center">
			
				  	<br>
			 		
					<label>Full Name: 
					    <input type="text" name="name" value="" placeholder="Full name" autocomplete="on" required>
					</label><br><br>
					<label>Address:
						 <input type="text" name="address" value="" placeholder="address" required>
					</label><br><br>
					<label>Contact:
						 <input type="text" name="contact" value="" placeholder="contact"  maxlength="10" required>
					</label><br><br>

					<label>Email:
						 <input type="email" name="email"  value="" placeholder="email" required>
					</label><br><br>
					
					<label>Select Expertise:
						 <select name="expertise" required >
								<option>-Select expertise-</option>
								<option>Individual Counselling </option>
								<option>Career Counselling</option>
								<option>Academic Counselling</option>
								<option>Religious Counselling</option>
							</select>
					</label><br><br>
					<label>User ID:
					     <input type="text" name="userid" value="" placeholder="userid" required>
					</label><br><br>
					<label>
						Password: <input type="password" id="psw" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Check the format below. Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="password" required>
					</label><br><br>
					<!--<label>
						 <input type="file" name="pic" value="" id="pic" required>
					</label><br><br>-->
					
					<button name="submit" type="submit" class="ripple2" id="button">Add counsellors</button> <br><br>
                                        
                                        <br><div id="rightdivcard">
                                                        <div id="message">
                                                        <h3>Password must contain the following:</h3>
                                                        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                                        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                                        <p id="number" class="invalid">A <b>number</b></p>
                                                        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                                                        </div>
                                                  </div><br
				</form>
                                        <div id="rightdivcard">
                                                        <div id="message">
                                                        <h3>Password must contain the following:</h3>
                                                        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                                        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                                        <p id="number" class="invalid">A <b>number</b></p>
                                                        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                                                        </div>
                                                  </div>
	</div>
      
	  <script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
	
	
	

					<!-- Validating users inputs and inserting it into database-->
					<?php 					
						include('../config.php');
						if(isset($_POST['submit'])){
						$sql1 = "SELECT * FROM counsellors WHERE userid='".$_POST["userid"]."' OR email= '" . $_POST["email"] . "' ";
	              		$result = $conn->query($sql1);
	              			if($result->num_rows > 0){
	              				echo "<script>alert('Sorry, Userid or E-mail already exist!');</script>";
	              			}
	              			else{                           
                                            
                                                                        //HASH CHANGE
                                                           $password = $_POST['password'];

                                                           $hash = sha1($password);
                
                                                          // $insert = $db->query("INSERT INTO admin(username,password) VALUES('$username','$hash') ");
                                                             //END
                                                    
                                                        //$sql = "INSERT INTO student (name,age,contact,address,bgender,email, password)
							//VALUES ('" . $_POST["name"] ."','" . $_POST["age"] . "','" . $_POST["contact"] . "','" . $_POST["address"] . "','" . $_POST["bgender"] . "', '" . $_POST["email"] . "','" . $hash . "' )";
                                                         
                                            
                                            
									$sql = "INSERT INTO counsellors (name,address,contact,email,expertise,userid,password)
										VALUES ('" . $_POST["name"] . "','" . $_POST["address"] . "','" . $_POST["contact"] . "','" . $_POST["email"] . "', '" . $_POST["expertise"] . "','" . $_POST["userid"] . "','" . $hash . "' )";

										if ($conn->query($sql) === TRUE) {
										    echo "<script>alert('New counsellors Has been Added Successfully!');</script>";
										    echo "<script>location.replace('editCounsellor.php');</script>";
										} else {
										    echo "<script>alert('There was an Error')<script>";
										}
									}
								}
									$conn->close();

			
				?>


	



	
	</div>




	<script src="js/bootstrap.min.js"></script>


	<?php include('footer.php'); ?>



</body>
</html>