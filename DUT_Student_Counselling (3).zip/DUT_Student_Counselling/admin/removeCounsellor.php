<?php
	include('config.php');
		
	if(isset($_REQUEST['cou_id'])){
		$cou_id=$_REQUEST['cou_id'];
		
		$sql = "DELETE FROM counsellors WHERE `cou_id`='$cou_id'";

		mysqli_query($conn, $sql);
		
		header('location:editCounsellor.php');
	}
?> 

