<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php
					if(isset($_POST["submit"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:addcounsellors2.php?".$queryString);
        				die();
        			}
        	if(isset($_POST["submit1"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:viewcounsellors.php?".$queryString);
        				die();
        			}
        	if(isset($_POST["submit2"]))	{		
								$queryString =  $_SERVER['QUERY_STRING'];   
        				header("Location:editCounsellor.php?".$queryString);
        				die();
        			}
					?>
<?php include('header.php'); ?>
<head>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<style type="text/css">

	.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  
}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:20px;
  padding:8px;
  padding-left:20px;
  padding-right:20px;
  background-color: red;

}

#leftbutton{
    background-color:#00cc00;
    border-radius:5px;
    color:#FAFAFA;
}
table{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 1000px;

}

tr{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;


}

.item-align{
	align-items: flex-end;
}



.flip-card {
  background-color: transparent;
  width: 450px;
  height: 345px;
  perspective: 1000px;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}

.flip-card:hover .flip-card-inner {
  transform: rotateX(180deg);
}

.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
}

.flip-card-front {
  background-color: #d4d7de;
  color: black;
  padding-top: 30%;
}

.flip-card-back {
  background-color: #7d869b;
  transform: rotateX(180deg);
  padding-top: 20%;
}

button{
	
	background-color: #6f7990;
	border: none;
	color: white;
	width: 195px;
	height: 172.5px;
	font-size: 100px;
	animation: 10s;
}
button:hover{
	 background-color: #d4d7de;
	 color: black;
}
.h2{
	padding-top: 10px;
}
</style>

<div class="about-section">
  <br><br>
  <hr><h1>Counsellors</h1><hr>
<br>
	<form action="" method="post" class="text-center">
<table>
	<tr>
		<td>
					<div class="flip-card">
 						 <div class="flip-card-inner">
    					<div class="flip-card-front">
      					<h2 class="h2"><b>Register New Counsellor</b></h2> 
    					</div>
    					<div class="flip-card-back">
    						<button name="submit" type="submit"><i class='fas fa-plus'></i></button>
    					</div>
  					</div>
					</div>

				</td>
				<td>			
					<div class="flip-card">
 						 <div class="flip-card-inner">
    					<div class="flip-card-front">
      					<h2><b>View and Edit<br>Counsellor Information</b></h2> 
    					</div>
    					<div class="flip-card-back">
    						<button name="submit2" type="submit2"><i class='fas fa-edit'></i></button>
    					</div>
  					</div>
					</div>
				</td>
	</tr>
</table>
</form>

	</div>


<script src="js/bootstrap.min.js"></script>	


</body>
</html>
<?php include('footer.php'); ?>