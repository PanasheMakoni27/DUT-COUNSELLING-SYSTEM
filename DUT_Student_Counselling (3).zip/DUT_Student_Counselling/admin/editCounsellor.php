<?php if(!isset($_SESSION)){
  session_start();
  }  
?>
<?php include('header.php'); ?>
<head>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>
<style type="text/css">

  .about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  font-size: 20px;
}

.ripple{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #e60000;
  color: white;

}

.ripple2{
  outline: none !important;
  margin-bottom:0;
  border:none;
  font-size:18px;
  padding:0px;
  padding-left:20px;
  padding-right:20px;
  border-radius: 5px;
  background-color: #00cc00;
  color: white;

}

button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 65px;
  height: 28px;
  text-align: center;
  cursor: pointer;
  padding-top: 12px;
}
table{
  align-items:center;
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px; 
}
th{
  text-align: center;
  max-width: 200px;
  font-size: 18px;
}
h3{
  color: white;
}
img{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
  
  color: white;
}
.item-align{
  align-items: flex-end;
}
</style>
<br>
<div class="about-section">
      <br>
      <hr>
      <h1>Edit Information</h1>
      <hr>
      <br>




  <div class="all_user" style="margin-top:0px; margin-left: 40px; ">
          <?php 
          include('../config.php');
          

          $sql = " SELECT * FROM counsellors";
          $result = mysqli_query($conn,$sql);
          $count = mysqli_num_rows($result);

          if($count>=1){
            echo "<table border='1' align='center' cellpadding='12'>
              <tr>
                
                <th>Name</th>
                <th>Address</th>
                
                <th>Mobile</th>
                
                <th>Email</th>
                <th>Expertise in</th>
                <th>Edit</th>
                <th>Delete</th>
                
              </tr>";
            while($row=mysqli_fetch_array($result)){
                echo "<tr>";
          
                echo "<td>".$row['name']."<hr></td>";
                echo "<td>".$row['address']."<hr></td>";
                
                echo "<td>".$row['contact']."<hr></td>";
                echo "<td>".$row['email']."<hr></td>";

                echo "<td>".$row['expertise']."<hr></td>";
                
               

                echo "<td><button id='button' class='ripple2'><a href='editCounsellorInfo.php?cou_id=".$row['cou_id']."'><i class='fas fa-pen' style='font-size:18px'></i></a></button><hr></td>";

                echo "<td><button id='button' class='ripple'><a href='removeCounsellor.php?cou_id=" .$row['cou_id']. "'><i class='fa fa-trash' style='font-size:18px'></i></a></button><hr></td>";

            ?>
            <?php     
                
                echo "</tr>";
            }
            echo "</table>";
          } 
          else{
            print "<p align='center'>Sorry, there currently no registered counsellors.</p>";
          }

          ?><br><br><br><br>
        </div>
  </div>

 <script src="js/bootstrap.min.js"></script>

  
</body>
</html> 
<?php include('footer.php'); ?>








  


