<?php
	include('config.php');
		
	if(isset($_REQUEST['id'])){
		$id=$_REQUEST['id'];
		
		$sql = "DELETE FROM student WHERE `id`='$id'";

		mysqli_query($conn, $sql);
		
		header('location:viewStudent.php');
	}
?> 

