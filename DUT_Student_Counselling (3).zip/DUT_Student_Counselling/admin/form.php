<?php if(!isset($_SESSION)){
    session_start();
    }  
?>

<?php include('header.php'); ?>

<style type="text/css">
    .about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  font-family: Quicksand;
  color: white;
}

form{
    text-align: left;
    width: 500px;
    background-color: #333;
}

:root {
  --dark-grey: #9FABAE; 
  --light-grey: #DFE3E4;
  --green: #2ECC71;
}

body {
  font-family: 'Quicksand', sans-serif;
  display: fill; /*change to fill*/
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
}

.container {
  margin: 50px auto;
}


button {
  background: #00cc00;
  border: 0;
  padding: 8px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 125px;
  text-align: center;
  cursor: pointer;
}
table{
    align-items:center;
    background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
}
h3{
    color: white;
}
img{
    background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
a{
    color: white;
}

form{
    padding: 100px;
    width: 100%;
    height: 100%;
    background-color: dimgrey;
}
input{
    color: black;
}

</style>

                <?php 
                            include('../config.php');
                            
                            $sql="SELECT * FROM student where email='" . $_SESSION["email"] . "'";
            
                            $q=mysqli_query($conn,$sql);
                            $row=mysqli_num_rows($q);
                            
                            $data=mysqli_fetch_array($q);
                            $name = $data[1];
                            $email=$data[6];
                            $password = " '$data[7]' LIMIT 1";

                            mysqli_close($conn);
                ?>

                <?php 
                            include('../config.php');
                            
                            $sql="SELECT * FROM feedback where email='" . $_SESSION["email"] . "'";
            
                            $q=mysqli_query($conn,$sql);
                            $row=mysqli_num_rows($q);
                            
                            $data=mysqli_fetch_array($q);
                            $feedback = $data[2];
                            

                            mysqli_close($conn);
                ?>



        <div class="about-section">
            
            <hr>
            <h1>Query response email</h1>
            <hr>
            <br>
        
            <table>
                <tr>
                    <td>
                <form action="sendemail.php" method="post" class="text-center">
                    <label>
                        Student Name:<input type="text" name="name"  value="<?php echo $name; ?>" required>
                    </label><br><br>
                    <label>
                        Student Email:<input type="email" name="email"  value="<?php echo $email; ?>" required>
                    </label><br><br>
                    <label>
                        Query:<input type="text" name="subject"  value="<?php echo $feedback; ?>" required>
                    </label><br><br>
                    <label>
                        Response:
                        <textarea name="message"></textarea required>
                    </label><br><br><br>
             
                    <button name="submit" type="submit" id="button"  style="width: 128px;height: 35px">Send Email</button> 

                </form>


    
            </td>
        </tr>
        </table>

                 <br>&nbsp;&nbsp;&nbsp;
                

                <br>

                
        
                
            
         
    </div>
        
        
            
      
    </div>
    
    

    
  <?php include('footer.php'); ?>


    
    </div>




    <script src="js/bootstrap.min.js"></script>
    <script src='https://meet.jit.si/external_api.js'></script>


 
            



    
</body>
</html>
