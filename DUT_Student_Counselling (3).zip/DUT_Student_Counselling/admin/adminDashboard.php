<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>

<style type="text/css">
	
		.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  width: 100%;
}

table{
  align-items:center;
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;

}

th{
  text-align: center;
  max-width: 200px;
  font-size: 18px;
}
input{
	height: 10px;
	padding-left: 1px;
}

button{
	border: none;
	border-radius: 1px;
	height: 25px;
	width: 25px;
	padding-left: 1px;
	
}
button {
  background: #00cc00;
  border: 0;
  
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 85px;
  height: 28px;
  text-align: center;
  cursor: pointer;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.2s;
  width: 100%;
  color: black;
  background-color: white;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,1.0);
}

.container {
  padding: 2px 16px;
  padding-top: 5px;
  padding-left: 10px;
  padding-bottom: 10px;
}
</style>

<br>
<div class="about-section">
<br>
<hr><h1>Dashboard</h1><hr>

	<div class="all_user" style="margin-top:0px; margin-left: 40px;">
		<div class="about-section"><br><hr><h1>Queries</h1><hr><br>


				<?php
	include('../config.php');
		
		$sql = "SELECT * FROM feedback ";
		mysqli_query($conn, $sql);

		$result = $conn->query($sql);

		$count = mysqli_num_rows($result);

        if($count>=1){
		
		while($row  = $result->fetch_assoc()) {						    

            echo"<div class='card'>";
            echo"<div class='container'>";
            echo"<h3><b>Queries</b></h3>";
            echo"<p><h4>User <b>".$row['email']."</b> has queried <b>".$row['feedback']."</b> </h4></p>";
            echo"</div>";
            echo"</div>";
          }
							}
else{

echo'<div class="card">';
echo' <div class="container">';
echo'  <h4><b>Queries</b></h4> ';
echo'   <p>There are no queries at the moment</p> ';
echo'  </div>';
echo'</div>';

}
							
			$conn->close();


        
?>
		</div>	
	</div>


</div>


<?php include('footer.php'); ?>


<script src="js/bootstrap.min.js"></script>
</body>
</html>
