<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>

<style type="text/css">
	
		.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
  font-family: Quicksand;
  width: 100%;
}

table{
  align-items:center;
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  width: 100%;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
  background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
  color: white;
  font-size: 18px;
  padding: 10px;

}

th{
  text-align: center;
  max-width: 200px;
  font-size: 18px;
}
input{
	height: 10px;
	padding-left: 1px;
}

button{
	border: none;
	border-radius: 1px;
	height: 25px;
	width: 25px;
	padding-left: 1px;
	
}
button {
  background: #00cc00;
  border: 0;
  
  border-radius: 5px;
  font-weight: bold;
  color: #fff;
  width: 85px;
  height: 28px;
  text-align: center;
  cursor: pointer;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.2s;
  width: 100%;
  color: black;
  background-color: white;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,1.0);
}

.container {
  padding: 2px 16px;
  padding-top: 5px;
  padding-left: 10px;
  padding-bottom: 10px;
}
</style>

<br>
<div class="about-section">
<br>
<hr><h1>Queries</h1><hr>

	<div class="all_user" style="margin-top:0px; margin-left: 40px;">
		

				<?php 
					include('../config.php');
					$sql = " SELECT * FROM feedback";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count>=1){
						echo "<table border='1' align='center' cellpadding='12'>
							<tr>
								<th>ID</th>
								<th>Email</th>
								<th>FeedBack</th>
								<th>View and Respond</th>
								
								
							</tr>";
						while($row=mysqli_fetch_array($result)){
								echo "<tr>";
								echo "<td>".$row['id']."<hr></td>";
								echo "<td>".$row['email']."<hr></td>";
								echo "<td>".$row['feedback']."<hr></td>";

								echo "<td><button id='button' class='ripple2'><a href='viewQueries.php?id=".$row['id']."'><i class='fas fa-eye' style='font-size:18px'></i></a></button><hr></td>";

								

								echo "</tr>";
						}
						echo "</table>";
					}
					else{
						print "<p align='center'>Sorry, there are no new queries.</p>";
					}

				?>
		
	</div>

<br><br><br> <br><br><br><br><br><br><br><br>
</div>


<?php include('footer.php'); ?>


<script src="js/bootstrap.min.js"></script>
</body>
</html>
