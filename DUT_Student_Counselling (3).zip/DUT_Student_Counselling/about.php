<?php include('header.php'); ?>
<?php 

if(isset($_POST["submit1"]))
{
  header('location:student_login.php');
  exit();
}

?>
<style type="text/css">

.hr {
  color: white;
  width: 175px;

}
.info {

  border: 0.5px solid grey;
  border-radius: 8px;
  padding: 5px;
  max-width: 1500px;
  max-height:300px;
  margin: auto;
  text-align: left;
  border: none;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  background-color: none;
  
}

.title {
  color: black;
  font-size: 18px;
}
.title1 {
  color: black;
  font-size: 13.5px;
}


/* Set height of body and the document to 100% to enable "full page tabs" */
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial;
}

/* Style tab links */
.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

.tablink:hover {
  background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
  color: black;
  display: none;
  padding: 100px 20px;
  height: 100%;
}

#Home {background-color: #ffdab3;}
#News {background-color: #adebad;}
#Contact {background-color: #b3ecff;}
#About {background-color: #ffff99;}

table{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
tr{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
td{
   background-color: rgba(0, 0, 0, 0.0);
  opacity: 1;
}
.p{
  text-align: left;
}
.about-section {
  padding: 50px;
  text-align: left;
  background-color: #474e5d;
  color: white;
}
.expectations {
  padding: 20px;
  text-align: left;
  background-color: #434956;
  color: white;
}
.meet-counsellors {
  padding: 20px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

 .vertical {
            border-left: 1px solid black;
            height: 200px;
            position:relative;
            left: 50%;
        }
form{
  width: 100px;
  height: 100px;
  padding: 50px;
  align-items: center;
  background-color: blueviolet;
  color: white;
}
input{
  width: 100%;
  height: 50px;
  padding: 20px;
  text-align: left;
  background-color: green;
  color: white;
}
.hr1{
  width: 60%;
  align-items: center;
}

</style>
</head>

<body>
<br>
<div class="counsellors">
<div class="form-group mc">
<div class="about-section">
<hr>
  <h1>About Us</h1>
  <hr>
  <p class="p">Student Support Services aims to ensure that students’ personal and 
        emotional needs are met. We are aware that many students’ academic performance is negatively
        affected by difficult personal circumstances. Our aim is to support ALL students in a holistic manner.
        To do this, we provide academic support in the form of study skills and time management workshops; and 
        psychological support for students experiencing personal and psychological difficulties. No problem is
        too big or too small and every student matters to us.</p>
<br>
<hr><h3 class="text-center">Services We Provide</h3><hr>

<button class="tablink" onclick="openPage('Home', this, '#ff9933')">Individual Counselling</button>
<button class="tablink" onclick="openPage('News', this, '#33cc33')" id="defaultOpen">Career Counselling</button>
<button class="tablink" onclick="openPage('Contact', this, '#1ac6ff')">Academic Couselling</button>
<button class="tablink" onclick="openPage('About', this, '#ffd633')">Lifeskills Development and Training</button>


<div id="Home" class="tabcontent">
    <div class="info">
      <table>
        <tr>
          <td>
          <p class="title"><h3>Individual Counselling<hr></h3></p>
          <p class="title1">What does it entail:</p>
          <p>Our individual counsellors aim help individuals deal with thoughts of suicide; addictions and substance abuse; family, parenting, and marital problems; stress management; problems with self-esteem; and issues associated with aging and mental and emotional health.</p>
          </td>
        </tr>
      </table>
    </div>

</div>



<div id="News" class="tabcontent">
  <div class="info">
    <table>
      <tr>
      <td>
      <p class="title"><h3>Career Counselling<hr></h3></p>
      <p class="title1">What does it entail:</p>
      <p>Career guidance and course information for prospective students
		<br> Career support and development for registered students</p>
      </td>
      </tr>
    </table>
  </div>
</div>

<div id="Contact" class="tabcontent">
  <div class="info">
    <table>
      <tr>
      <td>
      <p class="title"><h3>Academic Counselling<hr></h3></p>
      <p class="title1">What does it entail:</p>
      <p>Study skills counselling for test and exam preparation
       <br>Academic support for registered students</p>
      </td>
      </tr>
    </table>
  </div>
</div>

<div id="About" class="tabcontent">
  <div class="info">
    <table>
      <tr>
      <td>
      <p class="title"><h3>Lifeskills Development and Training<hr></h3></p>
      <p class="title1">What does it entail:</p>
      <p>A variety of trainin programmes are offered to enhance the academic, career and personal development of students at strategic times of the year.<br> The programmes include:<br>

		<ul>Work preparation skills</ul>
		<ul>Leadership development & Study skills</ul></p>
      </td>
      </tr>
    </table>
    </div>
</div>

  <hr>
  <h3>What to Expect from Our Counsellors</h3>
  <hr>
  <p>
      Every other day students are battling with a silent killer, struggling to find 
      peace within their souls, dying inside yet they still have to focus on their 
      studies. They need a best friend they can fully trust our student counsellors 
      therefore help students identify root causes of these ills that cause havoc in 
      their lives. Student counsellors provide instructions on psychological and social 
      issues, given the fact that some students cannot open up to their parents it is 
      mandatory that they are taught about sex and bullying, how to deal with 
      personal struggles as these are main factors causing depression among DUT 
      students.<br><br>
      Unfortunately some students have to deal with trauma, accident, 
      rape these factors causes anxiety, suicidal thoughts, depression, and stress, 
      counsellors help students find a balance on everyday life and also assist 
      students to resolve their personal issues internally and externally at their own 
      pace. This puts the students mind at ease as they are not rushed into recovery. 
      Counsellors main objective is promoting well-being of our students and help 
      students find themselves again so they can fully focus their healthy minds on 
      their school work! This is only achievable through admitting that you have a 
      problem and you cant solve it on your own hence we welcome all students to 
      book their DUT student consultations that is at their disposal. A healthy mind is 
      a healthy student, let us help you succeed
  </p>

  <hr>
  <h3>Where are we located</h3>
  <hr>
  <img src="photo/SteveBikoMap.jpg" style="width:100%; ; height:800px">

</div>
</div>
</div>
<?php include('footer.php'); ?>

<script src="js/jquery-1.11.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
function openPage(pageName, elmnt, color) {
  // Hide all elements with class="tabcontent" by default */
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(pageName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
</body>
</html>






